.. automodule:: smartypants_command
  :members:
