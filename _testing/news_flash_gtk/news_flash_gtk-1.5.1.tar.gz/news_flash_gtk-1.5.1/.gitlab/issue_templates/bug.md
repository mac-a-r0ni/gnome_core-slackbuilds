General Information:

 - Distribution: 
 - Desktop Environment:
 - NewsFlash Package Type:
 - NewsFlash Version:
 - NewsFlash Back-end: Local RSS / feedly / etc.

**Observed behavior and how to reproduce:**



**Expected behavior:**


