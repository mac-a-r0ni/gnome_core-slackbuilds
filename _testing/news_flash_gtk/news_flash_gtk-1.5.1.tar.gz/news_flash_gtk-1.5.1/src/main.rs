#![allow(clippy::derive_hash_xor_eq)]

mod about_dialog;
mod account_popover;
mod add_dialog;
mod app;
mod article_list;
mod article_view;
mod color;
mod config;
mod content_page;
mod discover;
mod enclosure_popover;
mod error_bar;
mod error_dialog;
mod i18n;
mod login_screen;
mod main_window;
mod main_window_state;
mod rename_dialog;
mod reset_page;
mod responsive;
mod settings;
mod sidebar;
mod tag_popover;
mod undo_bar;
mod util;
mod welcome_screen;

use crate::app::App;
use crate::config::{APP_ID, VERSION};
use log::LevelFilter;
use log4rs::append::console::ConsoleAppender;
use log4rs::config::{Appender, Config, Logger, Root};
use log4rs::encode::pattern::PatternEncoder;
use rust_embed::RustEmbed;
use std::str;

#[derive(RustEmbed)]
#[folder = "data/resources/"]
struct Resources;

fn main() {
    // nicer backtrace
    color_backtrace::install();

    let matches = clap::App::new("NewsFlash")
        .version(VERSION)
        .author("Jan Lukas Gernert <jangernert@gmail.com>")
        .about("Feed Reader written in GTK")
        .arg(
            clap::Arg::with_name("VERBOSE")
                .short("v")
                .long("verbose")
                .help("Sets the level of logs to debug.")
                .required(false)
                .multiple(false)
                .takes_value(false),
        )
        .arg(
            clap::Arg::with_name("INSPECT")
                .short("i")
                .long("inspect")
                .help("Allow to show webview inspector.")
                .required(false)
                .multiple(false)
                .takes_value(false),
        )
        .arg(
            clap::Arg::with_name("HEADLESS")
                .short("h")
                .long("headless")
                .help("Start without showing the window.")
                .required(false)
                .multiple(false)
                .takes_value(false),
        )
        .get_matches();

    let log_level = if matches.is_present("VERBOSE") {
        LevelFilter::Debug
    } else {
        LevelFilter::Info
    };

    let allow_inspector = matches.is_present("INSPECT");
    let headless = matches.is_present("HEADLESS");

    // Logging
    let encoder = PatternEncoder::new("{d(%H:%M:%S)} - {h({({l}):5.5})} - {m:<35.} (({M}:{L}))\n");
    let stdout = ConsoleAppender::builder().encoder(Box::new(encoder)).build();
    let appender = Appender::builder().build("stdout", Box::new(stdout));
    let root = Root::builder().appender("stdout").build(log_level);

    let reqwest = Logger::builder().additive(false).build("reqwest", LevelFilter::Off);
    let hyper = Logger::builder().additive(false).build("hyper", LevelFilter::Off);
    let trust_dns_resolver = Logger::builder()
        .additive(false)
        .build("trust_dns_resolver", LevelFilter::Off);
    let trust_dns_proto = Logger::builder()
        .additive(false)
        .build("trust_dns_proto", LevelFilter::Off);

    let config = Config::builder()
        .appender(appender)
        .logger(reqwest)
        .logger(hyper)
        .logger(trust_dns_resolver)
        .logger(trust_dns_proto)
        .build(root)
        .expect("Failed to create log4rs config.");
    let _handle = log4rs::init_config(config).expect("Failed to init log4rs config.");

    // Gtk setup
    gtk::init().expect("Error initializing gtk.");
    glib::set_application_name("NewsFlash");
    glib::set_prgname(Some("NewsFlashGTK"));
    gtk::Window::set_default_icon_name(APP_ID);
    libhandy::init();

    // Run app itself
    App::run(allow_inspector, headless);
}
