pub const TAG_DEFAULT_OUTER_COLOR: &str = "#FF0077";
pub const TAG_DEFAULT_INNER_COLOR: &str = "#FF0077";
