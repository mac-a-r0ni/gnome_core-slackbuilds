#!/bin/sh
echo running \'$0\'
echo PATH=\'$PATH\'
echo PYTHONPATH=\'$PYTHONPATH\'
echo python3=\>\'$(which python3)\'
echo python3.8=\>\'$(which python3.8)\'
echo gpg=\>\'$(which gpg)\'
