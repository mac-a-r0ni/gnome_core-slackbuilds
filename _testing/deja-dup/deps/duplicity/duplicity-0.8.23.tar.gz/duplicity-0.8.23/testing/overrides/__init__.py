# -*- Mode:Python; indent-tabs-mode:nil; tab-width:4; encoding:utf8 -*-
#
from __future__ import print_function
from future import standard_library
standard_library.install_aliases()
from builtins import filter
from builtins import map
from builtins import next
from builtins import object
from builtins import range
