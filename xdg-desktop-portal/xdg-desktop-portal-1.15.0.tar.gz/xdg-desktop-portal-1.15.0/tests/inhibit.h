#pragma once

void test_inhibit_basic (void);
void test_inhibit_delay (void);
void test_inhibit_close (void);
void test_inhibit_cancel (void);
void test_inhibit_parallel (void);
void test_inhibit_permissions (void);

void test_inhibit_monitor (void);
