
#pragma once

void test_notification_basic (void);
void test_notification_buttons (void);
void test_notification_bad_arg (void);
void test_notification_bad_priority (void);
void test_notification_bad_button (void);
