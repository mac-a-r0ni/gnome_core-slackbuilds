#pragma once

void settings_init (GDBusConnection *connection, const char *object_path);
