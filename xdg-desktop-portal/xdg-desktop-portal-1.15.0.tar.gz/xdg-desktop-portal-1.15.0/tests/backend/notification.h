#pragma once

void notification_init (GDBusConnection *connection, const char *object_path);
