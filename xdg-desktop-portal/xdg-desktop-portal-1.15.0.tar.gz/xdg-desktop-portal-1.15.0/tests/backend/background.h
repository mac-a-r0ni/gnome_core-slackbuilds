#pragma once

void background_init (GDBusConnection *connection, const char *object_path);
