#pragma once

void file_chooser_init (GDBusConnection *connection, const char *object_path);
