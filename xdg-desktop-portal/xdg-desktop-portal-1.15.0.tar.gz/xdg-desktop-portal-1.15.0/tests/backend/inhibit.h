#pragma once

void inhibit_init (GDBusConnection *connection, const char *object_path);
