#pragma once

void screenshot_init (GDBusConnection *connection, const char *object_path);
