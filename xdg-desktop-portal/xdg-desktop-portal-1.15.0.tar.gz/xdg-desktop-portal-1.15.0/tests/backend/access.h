#pragma once

void access_init (GDBusConnection *connection, const char *object_path);
