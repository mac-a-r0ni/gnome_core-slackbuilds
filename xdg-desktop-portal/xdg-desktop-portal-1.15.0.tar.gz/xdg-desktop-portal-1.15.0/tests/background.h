#pragma once

void test_background_basic1 (void);
void test_background_basic2 (void);
void test_background_commandline (void);
void test_background_reason (void);

