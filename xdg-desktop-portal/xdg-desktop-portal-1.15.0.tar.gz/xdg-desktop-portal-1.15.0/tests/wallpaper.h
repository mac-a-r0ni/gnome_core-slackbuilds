#pragma once

void test_wallpaper_basic (void);
void test_wallpaper_delay (void);
void test_wallpaper_cancel1 (void);
void test_wallpaper_cancel2 (void);
void test_wallpaper_permission (void);
