#pragma once

void test_open_uri_http (void);
void test_open_uri_http2 (void);
void test_open_uri_file (void);
void test_open_uri_delay (void);
void test_open_uri_close (void);
void test_open_uri_cancel (void);
void test_open_uri_lockdown (void);
void test_open_directory (void);
