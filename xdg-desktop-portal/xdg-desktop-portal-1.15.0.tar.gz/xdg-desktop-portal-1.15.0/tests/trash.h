#pragma once

void test_trash_file (void);
