#!/bin/bash

                  zenity --warning \
                  --text="Disconnect the power cable to avoid electrical shock." 
