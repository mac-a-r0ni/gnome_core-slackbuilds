#!/bin/bash

                  zenity --question \
                  --text="Are you sure you wish to proceed?"
