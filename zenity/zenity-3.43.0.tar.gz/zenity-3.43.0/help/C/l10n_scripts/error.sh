#!/bin/bash

                  zenity --error \
                  --text="Could not find /var/log/syslog." 
