#ifdef BORG_USE_BUNDLED_XXHASH
#include "xxh64/xxhash.h"
#else
#include <xxhash.h>
#endif
