__version__ = version = '1.2.2'
__version_tuple__ = version_tuple = (1, 2, 2)
