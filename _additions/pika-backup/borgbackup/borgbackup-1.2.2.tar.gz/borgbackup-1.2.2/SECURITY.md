# Security Policy

## Supported Versions

These borg releases are currently supported with security updates.

| Version | Supported          |
|---------|--------------------|
| 1.2.x   | :white_check_mark: |
| 1.1.x   | :white_check_mark: |
| < 1.1   | :x:                |

## Reporting a Vulnerability

See there:

https://borgbackup.readthedocs.io/en/latest/support.html#security-contact
