# Security Policy

## Supported Versions

We are following [CalVer](https://calver.org) with generous backward-compatibility guarantees. Therefore we only support the latest version.


## Reporting a Vulnerability

If you think you found a Vulnerability, please contact Hynek Schlawack at <hs@ox.cx>.

If you insist on using PGP, you can use the key `0xAE2536227F69F181`. The fingerprint must be `C2A0 4F86 ACE2 8ADC F817 DBB7 AE25 3622 7F69 F181`.  You can also find it on [Keybase](https://keybase.io/hynek).
