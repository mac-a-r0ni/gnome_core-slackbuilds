Credits & License
=================

*argon2-cffi* is maintained by `Hynek Schlawack <https://hynek.me/>`_ and released under the `MIT license <https://github.com/hynek/argon2-cffi/blob/main/LICENSE>`_.

The development is kindly supported by `Variomedia AG <https://www.variomedia.de/>`_.
Please consider `supporting me <https://hynek.me/say-thanks/>`_ too!

A full list of contributors can be found in GitHub's `overview <https://github.com/hynek/argon2-cffi/graphs/contributors>`_.
