/* This file was automatically generated, do not edit */
#include "common.h"
extern const unsigned p521_n_tables;
extern const unsigned p521_window_size;
extern const unsigned p521_points_per_table;
extern const uint64_t p521_tables[131][16][2][9];

