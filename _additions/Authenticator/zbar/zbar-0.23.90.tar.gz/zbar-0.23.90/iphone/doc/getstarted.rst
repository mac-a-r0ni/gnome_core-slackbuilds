*********************
   Getting Started
*********************

.. toctree::
   :maxdepth: 2
   :numbered:

   install
   tutorial
   faq
   support
