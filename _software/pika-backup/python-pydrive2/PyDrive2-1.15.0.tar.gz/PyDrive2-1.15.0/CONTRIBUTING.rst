Contributing guidelines
=======================

How to become a contributor and submit your own code
----------------------------------------------------

TODO

Contributing code
~~~~~~~~~~~~~~~~~

If you have improvements to PyDrive2, send us your pull requests! For those
just getting started, Github has a `howto <https://help.github.com/articles/using-pull-requests/>`_.
