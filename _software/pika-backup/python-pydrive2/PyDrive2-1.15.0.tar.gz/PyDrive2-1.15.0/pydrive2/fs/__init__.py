from pydrive2.fs.spec import GDriveFileSystem

__all__ = ["GDriveFileSystem"]
