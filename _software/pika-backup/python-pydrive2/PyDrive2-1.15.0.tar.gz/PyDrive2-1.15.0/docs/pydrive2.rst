pydrive2 package
================

pydrive2.apiattr module
-----------------------

.. automodule:: pydrive2.apiattr
    :members:
    :undoc-members:
    :show-inheritance:

pydrive2.auth module
--------------------

.. automodule:: pydrive2.auth
    :members:
    :undoc-members:
    :show-inheritance:

pydrive2.drive module
---------------------

.. automodule:: pydrive2.drive
    :members:
    :undoc-members:
    :show-inheritance:

pydrive2.files module
---------------------

.. automodule:: pydrive2.files
    :members:
    :undoc-members:
    :show-inheritance:

pydrive2.settings module
------------------------

.. automodule:: pydrive2.settings
    :members:
    :undoc-members:
    :show-inheritance:

pydrive2.fs module
------------------------

.. autoclass:: pydrive2.fs.GDriveFileSystem
    :show-inheritance:
