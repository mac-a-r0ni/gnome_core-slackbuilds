#ifdef BORG_USE_BUNDLED_ZSTD
#include "zstd/lib/zstd.h"
#else
#include <zstd.h>
#endif
