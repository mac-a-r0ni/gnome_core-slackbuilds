/* Configuration header created by Waf - do not edit */
#ifndef _CONFIG_H_WAF
#define _CONFIG_H_WAF

/* #define HAVE_SAMPLERATE 0 */
/* #define HAVE_PPOLL 0 */
/* #define HAVE_SNDFILE */
/* #define HAVE_NCURSES 0 */
/* #define HAVE_CELT 0 */
/* #define HAVE_CELT_API_0_11 0 */
/* #define HAVE_CELT_API_0_8 0 */
/* #define HAVE_CELT_API_0_7 0 */
/* #define HAVE_CELT_API_0_5 0 */
/* #define HAVE_READLINE 0 */
#define CLIENT_NUM 32
#define PORT_NUM_FOR_CLIENT 24
#define PORT_NUM 256
#define PORT_NUM_MAX 512
#define ADDON_DIR "/system/lib/jack"
#define JACK_LOCATION "/system/bin"
#define JACKMP 1
/* #define USE_POSIX_SHM 0 */
/* #define __CLIENTDEBUG__ 1 */

#endif /* _CONFIG_H_WAF */
