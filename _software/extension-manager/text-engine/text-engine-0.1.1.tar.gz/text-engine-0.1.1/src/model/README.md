# Model
This is the text engine document model. It is a platform agnostic representation
of a rich text document using a tree-like structure.
