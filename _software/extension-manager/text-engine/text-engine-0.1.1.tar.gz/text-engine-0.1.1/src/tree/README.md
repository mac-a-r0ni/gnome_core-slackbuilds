# Tree
A flexible tree/graph implementation. Used by the model
and layout stages to create and update intermediary
trees in the rendering process.
