# Text Engine
Text Engine is a rich-text editing framework for GTK 4. The primary user
of this library is [bluetype](https://github.com/mjakeman/bluetype) but it
can be used wherever rich text display and editing is needed.

## Matrix
Development of text-engine and bluetype takes place on matrix.

Join [#bluetype](https://matrix.to/#/#bluetype:matrix.org) to chat
about the project or if you would like to get involved. Come say hello!

## Licence
Text Engine is licensed under `LGPL-3.0-or-later`.
