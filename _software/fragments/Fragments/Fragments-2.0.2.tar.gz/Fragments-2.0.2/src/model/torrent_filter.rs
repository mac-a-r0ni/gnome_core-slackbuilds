// Fragments - torrent_sorter.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use glib::{ParamSpec, ParamSpecEnum, ToValue};
use gtk::glib;
use gtk::prelude::*;
use once_cell::sync::Lazy;

use std::cell::RefCell;

use transmission_gobject::{TrTorrent, TrTorrentStatus};

mod imp {
    use super::*;
    use glib::subclass::prelude::*;
    use gtk::subclass::filter::FilterImpl;

    #[derive(Debug, Default)]
    pub struct FrgTorrentFilter {
        status: RefCell<TrTorrentStatus>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgTorrentFilter {
        const NAME: &'static str = "FrgTorrentFilter";
        type Type = super::FrgTorrentFilter;
        type ParentType = gtk::Filter;
    }

    impl ObjectImpl for FrgTorrentFilter {
        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecEnum::new(
                    "status",
                    "Status",
                    "Status",
                    TrTorrentStatus::static_type(),
                    TrTorrentStatus::default() as i32,
                    glib::ParamFlags::READWRITE,
                )]
            });

            PROPERTIES.as_ref()
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "status" => self.status.borrow().to_value(),
                _ => unimplemented!(),
            }
        }

        fn set_property(
            &self,
            obj: &Self::Type,
            _id: usize,
            value: &glib::Value,
            pspec: &ParamSpec,
        ) {
            match pspec.name() {
                "status" => {
                    *self.status.borrow_mut() = value.get().unwrap();
                    obj.changed(gtk::FilterChange::Different);
                }
                _ => unimplemented!(),
            }
        }
    }

    impl FilterImpl for FrgTorrentFilter {
        fn match_(&self, filter: &Self::Type, item: &glib::Object) -> bool {
            let torrent = item.downcast_ref::<TrTorrent>().unwrap();
            torrent.status() == filter.status()
        }
    }
}

glib::wrapper! {
    pub struct FrgTorrentFilter(ObjectSubclass<imp::FrgTorrentFilter>) @extends gtk::Filter;
}

impl FrgTorrentFilter {
    pub fn new() -> Self {
        glib::Object::new(&[]).expect("Failed to create FrgTorrentFilter")
    }

    pub fn status(&self) -> TrTorrentStatus {
        self.property("status")
    }

    pub fn set_status(&self, status: TrTorrentStatus) {
        self.set_property("status", &status)
    }
}
