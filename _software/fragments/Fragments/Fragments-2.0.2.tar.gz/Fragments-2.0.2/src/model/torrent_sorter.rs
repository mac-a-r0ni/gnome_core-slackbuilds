// Fragments - torrent_sorter.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use glib::{Enum, ParamSpec, ParamSpecBoolean, ParamSpecEnum, ToValue};
use gtk::glib;
use gtk::prelude::*;
use once_cell::sync::Lazy;

use std::cell::RefCell;

use transmission_gobject::TrTorrent;

mod imp {
    use super::*;
    use glib::subclass::prelude::*;
    use gtk::subclass::sorter::SorterImpl;

    #[derive(Debug, Default)]
    pub struct FrgTorrentSorter {
        descending: RefCell<bool>,
        sorting: RefCell<FrgTorrentSorting>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgTorrentSorter {
        const NAME: &'static str = "FrgTorrentSorter";
        type Type = super::FrgTorrentSorter;
        type ParentType = gtk::Sorter;
    }

    impl ObjectImpl for FrgTorrentSorter {
        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![
                    ParamSpecBoolean::new(
                        "descending",
                        "Descending",
                        "Descending",
                        false,
                        glib::ParamFlags::READWRITE,
                    ),
                    ParamSpecEnum::new(
                        "sorting",
                        "Sorting",
                        "Sorting",
                        FrgTorrentSorting::static_type(),
                        FrgTorrentSorting::default() as i32,
                        glib::ParamFlags::READWRITE,
                    ),
                ]
            });

            PROPERTIES.as_ref()
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "descending" => self.descending.borrow().to_value(),
                "sorting" => self.sorting.borrow().to_value(),
                _ => unimplemented!(),
            }
        }

        fn set_property(
            &self,
            obj: &Self::Type,
            _id: usize,
            value: &glib::Value,
            pspec: &ParamSpec,
        ) {
            match pspec.name() {
                "descending" => {
                    *self.descending.borrow_mut() = value.get().unwrap();
                    obj.changed(gtk::SorterChange::Different);
                }
                "sorting" => {
                    *self.sorting.borrow_mut() = value.get().unwrap();
                    obj.changed(gtk::SorterChange::Different);
                }
                _ => unimplemented!(),
            }
        }
    }

    impl SorterImpl for FrgTorrentSorter {
        fn order(&self, _sorter: &Self::Type) -> gtk::SorterOrder {
            gtk::SorterOrder::Total
        }

        fn compare(
            &self,
            _sorter: &Self::Type,
            item1: &glib::Object,
            item2: &glib::Object,
        ) -> gtk::Ordering {
            let a = item1.downcast_ref::<TrTorrent>().unwrap();
            let b = item2.downcast_ref::<TrTorrent>().unwrap();
            super::FrgTorrentSorter::torrent_cmp(
                a,
                b,
                *self.sorting.borrow(),
                *self.descending.borrow(),
            )
            .into()
        }
    }
}

glib::wrapper! {
    pub struct FrgTorrentSorter(ObjectSubclass<imp::FrgTorrentSorter>) @extends gtk::Sorter;
}

impl FrgTorrentSorter {
    pub fn new() -> Self {
        glib::Object::new(&[]).expect("Failed to create FrgTorrentSorter")
    }

    pub fn sorting(&self) -> FrgTorrentSorting {
        self.property("sorting")
    }

    pub fn set_sorting(&self, sorting: FrgTorrentSorting) {
        self.set_property("sorting", &sorting);
    }

    pub fn descending(&self) -> bool {
        self.property("descending")
    }

    pub fn set_descending(&self, descending: bool) {
        self.set_property("descending", &descending);
    }

    fn torrent_cmp(
        a: &TrTorrent,
        b: &TrTorrent,
        sorting: FrgTorrentSorting,
        descending: bool,
    ) -> std::cmp::Ordering {
        let mut torrent_a = a.clone();
        let mut torrent_b = b.clone();

        if descending {
            std::mem::swap(&mut torrent_a, &mut torrent_b);
        }

        match sorting {
            FrgTorrentSorting::Default => std::cmp::Ordering::Equal,
            FrgTorrentSorting::Name => torrent_a.name().cmp(&torrent_b.name()),
            FrgTorrentSorting::Queue => torrent_a.queue_position().cmp(&torrent_b.queue_position()),
        }
    }
}

#[derive(Display, Copy, Debug, Clone, EnumString, PartialEq, Enum)]
#[repr(u32)]
#[enum_type(name = "FrgTorrentSorting")]
pub enum FrgTorrentSorting {
    Default,
    Name,
    Queue,
}

impl Default for FrgTorrentSorting {
    fn default() -> Self {
        FrgTorrentSorting::Default
    }
}
