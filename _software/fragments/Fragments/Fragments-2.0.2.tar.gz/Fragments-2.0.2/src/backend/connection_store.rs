// Fragments - connection_store.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use gio::ListStore;
use glib::{clone, KeyFile};
use gtk::prelude::*;
use gtk::{gio, glib};

use std::{fs, path::Path};

use crate::backend::FrgConnection;
use crate::path;

#[derive(Debug, Clone)]
pub struct ConnectionStore {
    connections: ListStore,
}

impl ConnectionStore {
    pub fn new(connections: ListStore) -> Self {
        let store = Self { connections };

        store.read_data();
        store.setup_signals();
        store
    }

    fn setup_signals(&self) {
        self.connections
            .connect_items_changed(clone!(@strong self as this => move |_, _, _, _|{
                this.write_data();
            }));
    }

    fn read_data(&self) {
        debug!("Read connection data");
        self.connections.remove_all();

        let path = Path::new(&*path::CONFIG).join("connections.conf");

        if !path.exists() {
            debug!("No connections file found, skip reading.");
            return;
        }

        let keyfile = KeyFile::new();
        keyfile
            .load_from_file(&path, glib::KeyFileFlags::NONE)
            .expect("Unable to load connections data");

        for group in keyfile.groups().0 {
            let title = keyfile
                .string(&group, "title")
                .expect("Unable to get connection title");
            let address = keyfile
                .string(&group, "address")
                .expect("Unable to get address title");

            let connection = FrgConnection::new_with_uuid(&title, &address, &group);
            self.connections.append(&connection);
        }
    }

    fn write_data(&self) {
        debug!("Write connection data");

        let keyfile = KeyFile::new();

        for pos in 0..self.connections.n_items() {
            let connection = self
                .connections
                .item(pos)
                .unwrap()
                .downcast::<FrgConnection>()
                .unwrap();

            // Don't save local Fragments connection
            if connection.is_fragments() {
                continue;
            }

            let uuid = connection.uuid();

            keyfile.set_string(&uuid, "title", &connection.title());
            keyfile.set_string(&uuid, "address", &connection.address());
        }

        let path = Path::new(&*path::CONFIG).join("connections.conf");

        fs::write(&path, keyfile.to_data().as_bytes()).expect("Unable to write connections data");
    }
}
