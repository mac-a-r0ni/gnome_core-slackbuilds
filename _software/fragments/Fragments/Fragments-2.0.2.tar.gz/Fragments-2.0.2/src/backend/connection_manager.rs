// Fragments - connection_manager.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use async_std::task;
use gio::prelude::*;
use gio::ListStore;
use glib::{ParamFlags, ParamSpec, ParamSpecObject};
use gtk::subclass::prelude::*;
use gtk::{gio, glib};
use once_cell::sync::Lazy;
use transmission_gobject::{ClientError, TrClient};

use std::cell::RefCell;
use std::convert::TryInto;
use std::time::Duration;

use crate::app::FrgApplication;
use crate::backend::{ConnectionStore, Daemon, FrgConnection};
use crate::settings::{settings_manager, Key};

mod imp {
    use super::*;

    pub struct FrgConnectionManager {
        pub client: TrClient,
        pub connections: ListStore,
        pub connection_store: ConnectionStore,
        pub current_connection: RefCell<FrgConnection>,
        pub daemon: Daemon,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgConnectionManager {
        const NAME: &'static str = "FrgConnectionManager";
        type Type = super::FrgConnectionManager;
        type ParentType = glib::Object;

        fn new() -> Self {
            let connections = ListStore::new(FrgConnection::static_type());
            let connection_store = ConnectionStore::new(connections.clone());

            Self {
                client: TrClient::new(),
                connections,
                connection_store,
                current_connection: RefCell::default(),
                daemon: Daemon::new(),
            }
        }
    }

    impl ObjectImpl for FrgConnectionManager {
        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![
                    ParamSpecObject::new(
                        "client",
                        "Client",
                        "Client",
                        TrClient::static_type(),
                        ParamFlags::READABLE,
                    ),
                    ParamSpecObject::new(
                        "connections",
                        "Connections",
                        "Connections",
                        ListStore::static_type(),
                        ParamFlags::READABLE,
                    ),
                    ParamSpecObject::new(
                        "current-connection",
                        "Current connection",
                        "Current connection",
                        FrgConnection::static_type(),
                        ParamFlags::READABLE,
                    ),
                ]
            });
            PROPERTIES.as_ref()
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "client" => self.client.to_value(),
                "connections" => self.connections.to_value(),
                "current-connection" => self.current_connection.borrow().to_value(),
                _ => unimplemented!(),
            }
        }
    }
}

glib::wrapper! {
    pub struct FrgConnectionManager(ObjectSubclass<imp::FrgConnectionManager>);
}

impl FrgConnectionManager {
    pub fn new() -> Self {
        glib::Object::new(&[]).unwrap()
    }

    pub async fn connect(&self, connection: &FrgConnection) -> Result<(), ClientError> {
        let imp = imp::FrgConnectionManager::from_instance(self);

        debug!("Connect to {}", &connection.address());
        *imp.current_connection.borrow_mut() = connection.clone();
        self.notify("current-connection");

        let polling_rate = Self::polling_rate(&connection);
        let res = imp.client.connect(connection.address(), polling_rate).await;

        // Save connection uuid to restore the connection on next Fragments startup
        settings_manager::set_string(Key::ClientLastConnection, connection.uuid());

        if let Err(ref err) = res {
            warn!(
                "Can't connect to {}: {}",
                &connection.address(),
                err.to_string()
            );
        } else {
            debug!("Connected with {}", &connection.address());
        }

        res
    }

    pub async fn disconnect(&self) -> anyhow::Result<()> {
        let imp = imp::FrgConnectionManager::from_instance(self);

        debug!("Disconnect from {}", &imp.client.address());
        imp.client.disconnect(false).await;

        Ok(())
    }

    /// `filename` can be a magnet url or a local file path
    pub async fn add_torrent_by_filename(&self, filename: String) -> anyhow::Result<()> {
        let imp = imp::FrgConnectionManager::from_instance(self);
        debug!("Add new torrent by filename: {}", filename);
        imp.client.add_torrent_by_filename(filename).await?;
        Ok(())
    }

    /// `metainfo` is the base64 encoded content of a .torrent file
    pub async fn add_torrent_by_metainfo(&self, metainfo: String) -> anyhow::Result<()> {
        let imp = imp::FrgConnectionManager::from_instance(self);
        debug!("Add new torrent by metainfo.");
        imp.client.add_torrent_by_metainfo(metainfo).await?;
        Ok(())
    }

    pub async fn start_daemon(&self) -> anyhow::Result<()> {
        let imp = imp::FrgConnectionManager::from_instance(self);
        imp.daemon.start().await?;

        // Wait a bit to ensure that the daemon accepts rpc requests
        task::sleep(Duration::from_millis(500)).await;

        Ok(())
    }

    pub async fn stop_daemon(&self) -> anyhow::Result<()> {
        // Gracefully disconnect from Fragments connection first
        if self.current_connection().is_fragments() {
            self.disconnect().await?;
        }

        let imp = imp::FrgConnectionManager::from_instance(self);
        imp.daemon.stop().await?;

        Ok(())
    }

    pub async fn restart_daemon(&self) -> anyhow::Result<()> {
        debug!("Restart daemon...");

        self.stop_daemon().await?;
        self.start_daemon().await?;

        if self.current_connection().is_fragments() {
            self.connect(&self.current_connection()).await?;
        }

        Ok(())
    }

    pub fn client(&self) -> TrClient {
        self.property("client")
    }

    pub fn connections(&self) -> ListStore {
        self.property("connections")
    }

    pub fn current_connection(&self) -> FrgConnection {
        self.property("current-connection")
    }

    pub fn connection_by_uuid(&self, uuid: &str) -> Option<FrgConnection> {
        let connections = self.connections();

        for pos in 0..connections.n_items() {
            let connection = connections
                .item(pos)
                .unwrap()
                .downcast::<FrgConnection>()
                .unwrap();

            if connection.uuid() == uuid {
                return Some(connection);
            }
        }

        None
    }

    fn polling_rate(connection: &FrgConnection) -> u64 {
        if connection.is_fragments() {
            settings_manager::get_integer(Key::ClientPollingRate)
                .try_into()
                .unwrap()
        } else {
            settings_manager::get_integer(Key::ClientRemotePollingRate)
                .try_into()
                .unwrap()
        }
    }
}

impl Default for FrgConnectionManager {
    fn default() -> Self {
        FrgApplication::default().connection_manager()
    }
}
