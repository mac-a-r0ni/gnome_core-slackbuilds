// Fragments - secret_store.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.
//
// Original source: Fractal (-next branch)
// https://gitlab.gnome.org/GNOME/fractal/-/blob/1d158e52ae1dd678664d07c6d28075c49557cbab/src/secret.rs

use crate::backend::FrgConnection;

use std::collections::HashMap;

use secret_service::{EncryptionType, SecretService};
use transmission_gobject::TrAuthentication;

pub fn store(conn: &FrgConnection, auth: &TrAuthentication) -> Result<(), secret_service::Error> {
    let ss = SecretService::new(EncryptionType::Dh)?;
    let collection = get_default_collection_unlocked(&ss)?;

    remove(&conn)?;

    let username = auth.username();
    let uuid = conn.uuid();

    let attributes: HashMap<&str, &str> =
        [("username", username.as_str()), ("uuid", uuid.as_str())]
            .iter()
            .cloned()
            .collect();

    let title = format!("Fragments ({})", conn.title());

    collection.create_item(
        title.as_str(),
        attributes,
        auth.password().as_bytes(),
        true,
        "text/plain",
    )?;

    Ok(())
}

pub fn get(conn: &FrgConnection) -> Result<Option<TrAuthentication>, secret_service::Error> {
    let ss = SecretService::new(EncryptionType::Dh)?;
    let collection = get_default_collection_unlocked(&ss)?;

    let uuid = conn.uuid();
    let attributes: HashMap<&str, &str> = [("uuid", uuid.as_str())].iter().cloned().collect();

    let items = collection.search_items(attributes)?;
    if let Some(item) = items.get(0) {
        let attributes = item.get_attributes()?;
        let username = attributes
            .get("username")
            .expect("Couldn't get secretservice username attribute");
        let password =
            String::from_utf8(item.get_secret()?).expect("Couldn't parse secretservice secret");

        Ok(Some(TrAuthentication::new(username, &password)))
    } else {
        Ok(None)
    }
}

pub fn remove(conn: &FrgConnection) -> Result<(), secret_service::Error> {
    let ss = SecretService::new(EncryptionType::Dh)?;
    let collection = get_default_collection_unlocked(&ss)?;

    let uuid = conn.uuid();
    let attributes: HashMap<&str, &str> = [("uuid", uuid.as_str())].iter().cloned().collect();

    let items = collection.search_items(attributes)?;

    for item in items {
        item.delete()?;
    }

    Ok(())
}

fn get_default_collection_unlocked<'a>(
    secret_service: &'a SecretService,
) -> Result<secret_service::Collection<'a>, secret_service::Error> {
    let collection = match secret_service.get_default_collection() {
        Ok(col) => col,
        Err(secret_service::Error::NoResult) => {
            secret_service.create_collection("default", "default")?
        }
        Err(error) => return Err(error),
    };

    collection.unlock()?;

    Ok(collection)
}
