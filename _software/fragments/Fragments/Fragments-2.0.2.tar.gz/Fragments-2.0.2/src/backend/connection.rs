// Fragments - connection.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use gio::prelude::*;
use glib::{ParamFlags, ParamSpec, ParamSpecBoolean, ParamSpecString};
use gtk::subclass::prelude::*;
use gtk::{gio, glib};
use once_cell::sync::Lazy;
use once_cell::unsync::OnceCell;
use uuid::Uuid;

use std::cell::Cell;

use crate::i18n::i18n;

static FRAGMENTS_UUID: &str = "00000000-0000-0000-0000-000000000000";

mod imp {
    use super::*;

    #[derive(Debug, Default)]
    pub struct FrgConnection {
        pub title: OnceCell<String>,
        pub address: OnceCell<String>,
        pub uuid: OnceCell<String>,
        pub is_fragments: Cell<bool>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgConnection {
        const NAME: &'static str = "FrgConnection";
        type Type = super::FrgConnection;
        type ParentType = glib::Object;
    }

    impl ObjectImpl for FrgConnection {
        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![
                    ParamSpecString::new(
                        "title",
                        "Title",
                        "Title",
                        "".into(),
                        ParamFlags::READWRITE | ParamFlags::CONSTRUCT_ONLY,
                    ),
                    ParamSpecString::new(
                        "address",
                        "Address",
                        "Address",
                        "".into(),
                        ParamFlags::READWRITE | ParamFlags::CONSTRUCT_ONLY,
                    ),
                    ParamSpecString::new(
                        "uuid",
                        "UUID",
                        "UUID",
                        "".into(),
                        ParamFlags::READWRITE | ParamFlags::CONSTRUCT_ONLY,
                    ),
                    ParamSpecBoolean::new(
                        "is-fragments",
                        "Is Fragments",
                        "Is Fragments",
                        false,
                        ParamFlags::READWRITE,
                    ),
                ]
            });
            PROPERTIES.as_ref()
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "title" => self.title.get().to_value(),
                "address" => self.address.get().to_value(),
                "uuid" => self.uuid.get().to_value(),
                "is-fragments" => self.is_fragments.get().to_value(),
                _ => unimplemented!(),
            }
        }

        fn set_property(
            &self,
            _obj: &Self::Type,
            _id: usize,
            value: &glib::Value,
            pspec: &ParamSpec,
        ) {
            match pspec.name() {
                "title" => self.title.set(value.get().unwrap()).unwrap(),
                "address" => self.address.set(value.get().unwrap()).unwrap(),
                "uuid" => self.uuid.set(value.get().unwrap()).unwrap(),
                _ => unimplemented!(),
            };
        }

        fn constructed(&self, obj: &Self::Type) {
            let is_fragments = &obj.uuid() == FRAGMENTS_UUID;
            self.is_fragments.set(is_fragments);

            self.parent_constructed(obj);
        }
    }
}

glib::wrapper! {
    pub struct FrgConnection(ObjectSubclass<imp::FrgConnection>);
}

impl FrgConnection {
    pub fn new(title: &str, address: &str) -> Self {
        let uuid = Uuid::new_v4().to_string();
        glib::Object::new(&[("title", &title), ("address", &address), ("uuid", &uuid)]).unwrap()
    }

    pub fn new_with_uuid(title: &str, address: &str, uuid: &str) -> Self {
        glib::Object::new(&[("title", &title), ("address", &address), ("uuid", &uuid)]).unwrap()
    }

    pub fn title(&self) -> String {
        self.property("title")
    }

    pub fn address(&self) -> String {
        self.property("address")
    }

    pub fn uuid(&self) -> String {
        self.property("uuid")
    }

    pub fn is_fragments(&self) -> bool {
        &self.uuid() == FRAGMENTS_UUID
    }
}

impl Default for FrgConnection {
    fn default() -> Self {
        Self::new_with_uuid(
            &i18n("Local Fragments session"),
            "http://127.0.0.1:9091/transmission/rpc",
            &FRAGMENTS_UUID,
        )
    }
}
