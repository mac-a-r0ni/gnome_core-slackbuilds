// Fragments - utils.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use ashpd::desktop::open_uri;
use ashpd::WindowIdentifier;
use glib::{clone, BindingFlags};
use gtk::prelude::*;
use gtk::{gdk, gio, glib};
use transmission_gobject::{ClientError, TrTorrent, TrTorrentStatus};

use std::{convert::TryInto, fs::File, path::Path};

use crate::backend::FrgConnectionManager;
use crate::i18n::{i18n, ni18n_f};
use crate::ui::{FrgApplicationWindow, FrgTorrentDialog};

pub fn inapp_notification<T: AsRef<str>>(text: T) {
    let window = FrgApplicationWindow::default();
    window.inapp_notification(text.as_ref());
}

pub fn system_notification<T: AsRef<str>>(title: T, subtitle: T, icon: Option<&str>) {
    let notification = gio::Notification::new(title.as_ref());
    notification.set_body(Some(subtitle.as_ref()));

    if let Some(icon) = icon {
        match gio::Icon::for_string(icon) {
            Ok(gicon) => notification.set_icon(&gicon),
            Err(err) => debug!("Unable to display notification: {:?}", err),
        }
    }

    gio::Application::default()
        .unwrap()
        .send_notification(None, &notification);
    debug!("System Notification: {}", title.as_ref());
}

pub fn bind_connected_property(action: &gio::SimpleAction) {
    let client = FrgConnectionManager::default().client();
    client
        .bind_property("is-connected", action, "enabled")
        .flags(BindingFlags::SYNC_CREATE)
        .build();
}

pub fn is_unauthorized(res: &Result<(), ClientError>) -> bool {
    if let Err(err) = res {
        match err {
            ClientError::TransmissionUnauthorized => return true,
            _ => (),
        }
    }

    false
}

pub fn format_size(size: i64) -> String {
    glib::format_size(size.try_into().unwrap_or(0)).to_string()
}

pub fn format_speed(speed: i32) -> String {
    format!("{}/s", format_size(speed as i64)).to_string()
}

pub fn format_time(total_seconds: u32, limit_at_day: bool) -> String {
    if total_seconds == u32::MAX || total_seconds == 4294967294 {
        warn!("Invalid seconds: {}", total_seconds);
        return "?".into();
    } else if total_seconds == 1 || total_seconds == 0 {
        return String::new();
    }

    if limit_at_day && total_seconds > 86400 {
        return i18n("more than a day");
    }

    let seconds: u32 = total_seconds % 60;
    let minutes: u32 = (total_seconds % 3600) / 60;
    let hours: u32 = (total_seconds % 86400) / 3600;
    let days: u32 = (total_seconds % (86400 * 60)) / 86400;

    let str_days = ni18n_f("{} day", "{} days", days, &[&days.to_string()]);
    let str_hours = ni18n_f("{} hour", "{} hours", hours, &[&hours.to_string()]);
    let str_minutes = ni18n_f("{} minute", "{} minutes", minutes, &[&minutes.to_string()]);
    let str_seconds = ni18n_f("{} second", "{} seconds", seconds, &[&seconds.to_string()]);

    if days > 0 {
        format!("{}, {}", str_days, str_hours).to_string()
    } else if hours > 0 {
        return format!("{}, {}", str_hours, str_minutes).to_string();
    } else if minutes > 0 {
        str_minutes
    } else if seconds > 0 {
        str_seconds
    } else {
        String::new()
    }
}

pub fn eta_text(torrent: &TrTorrent) -> String {
    match torrent.status() {
        TrTorrentStatus::Stopped => i18n("Paused"),
        TrTorrentStatus::Download => {
            let total_seconds: u32 = torrent.eta().try_into().unwrap_or(1);
            format_time(total_seconds, true)
        }
        // i18n: "Queued" is the current status of a torrent
        TrTorrentStatus::DownloadWait => i18n("Queued"),
        TrTorrentStatus::Check => i18n("Checking…"),
        // i18n: "Queued" is the current status of a torrent
        TrTorrentStatus::CheckWait => i18n("Queued"),
        TrTorrentStatus::Seed => i18n("Seeding…"),
        // i18n: "Queued" is the current status of a torrent
        TrTorrentStatus::SeedWait => i18n("Queued"),
    }
}

pub fn set_mime_type_image(mime_type: &str, image: &gtk::Image) {
    // TODO: Ensure that primary_mime_type works with transmission 3.1+
    let mime_type = if mime_type.is_empty() || mime_type == "0" {
        // Fallback to avoid ugly generic icon
        "text-x-generic"
    } else {
        mime_type
    };

    let icon = gio::content_type_get_symbolic_icon(mime_type);
    image.set_from_gicon(&icon);
}

pub fn install_torrent_actions(
    torrent: &TrTorrent,
    widget: gtk::Widget,
    parent_window: gtk::Window,
    close_on_torrent_remove: bool,
) {
    let actions = gio::SimpleActionGroup::new();
    widget.insert_action_group("torrent", Some(&actions));

    // torrent.continue
    let continue_action = gio::SimpleAction::new("continue", None);
    continue_action.connect_activate(clone!(@weak torrent => move |_, _| {
        let fut = async move {
            torrent.start(false).await.expect("Unable to start torrent");
        };
        spawn!(fut);
    }));
    actions.add_action(&continue_action);

    // torrent.pause
    let pause_action = gio::SimpleAction::new("pause", None);
    pause_action.connect_activate(clone!(@weak torrent => move |_, _| {
        let fut = async move {
            torrent.stop().await.expect("Unable to stop torrent");
        };
        spawn!(fut);
    }));
    actions.add_action(&pause_action);

    // Disable `continue`/`pause` action depending on the torrent status
    torrent.connect_notify_local(
        Some("status"),
        clone!(@weak torrent, @weak continue_action, @weak pause_action => move |_, _|{
            update_status_action(&torrent, &continue_action, &pause_action);
        }),
    );
    update_status_action(&torrent, &continue_action, &pause_action);

    // torrent.remove
    let remove_action = gio::SimpleAction::new("remove", None);
    remove_action.connect_activate(
        clone!(@weak torrent, @weak parent_window, @strong close_on_torrent_remove => move |_, _| {
            show_remove_torrent_dialog(&torrent, &parent_window, close_on_torrent_remove);
        }),
    );
    actions.add_action(&remove_action);

    // torrent.copy-magnet
    let copy_magnet_action = gio::SimpleAction::new("copy-magnet", None);
    copy_magnet_action.connect_activate(clone!(@weak torrent, @weak parent_window => move |_, _| {
        let display = gdk::Display::default().unwrap();
        let clipboard = display.clipboard();

        let content = gdk::ContentProvider::for_value(&torrent.magnet_link().to_value());
        if let Err(err) = clipboard.set_content(Some(&content)){
            inapp_notification(i18n("Unable to copy magnet link to clipboard"));
            warn!("Unable to copy magnet link to clipboard: {}", err.to_string());
        }

        inapp_notification(i18n("Copied magnet link to clipboard"));
    }));
    actions.add_action(&copy_magnet_action);

    // torrent.manual-update
    let manual_update_action = gio::SimpleAction::new("manual-update", None);
    manual_update_action.connect_activate(clone!(@weak torrent => move |_, _| {
        let fut = async move {
            torrent.reannounce().await.expect("Unable to reannounce torrent");
        };
        spawn!(fut);
    }));
    actions.add_action(&manual_update_action);

    // torrent.queue-up
    let queue_up_action = gio::SimpleAction::new("queue-up", None);
    queue_up_action.connect_activate(clone!(@weak torrent => move |_, _| {
        move_queue(false, torrent);
    }));
    actions.add_action(&queue_up_action);

    // torrent.queue-down
    let queue_down_action = gio::SimpleAction::new("queue-down", None);
    queue_down_action.connect_activate(clone!(@weak torrent => move |_, _| {
        move_queue(true, torrent);
    }));
    actions.add_action(&queue_down_action);

    // Disable queue actions for non queued torrents
    torrent.connect_notify_local(
        Some("status"),
        clone!(@weak torrent, @weak queue_up_action, @weak queue_down_action => move |_, _|{
            update_queue_action(&torrent, &queue_up_action, &queue_down_action);
        }),
    );
    update_queue_action(&torrent, &queue_up_action, &queue_down_action);

    // torrent.open-dialog
    let open_dialog_action = gio::SimpleAction::new("open-dialog", None);
    open_dialog_action.connect_activate(clone!(@weak torrent => move |_, _| {
        let dialog = FrgTorrentDialog::new(&torrent);
        dialog.show();
    }));
    actions.add_action(&open_dialog_action);

    // torrent.open
    let action = gio::SimpleAction::new("open", None);
    action.connect_activate(clone!(@weak torrent => move |_, _| {
        let fut = async move {
            match File::open(Path::new(&torrent.download_dir()).join(torrent.name())){
                Ok(file) => {
                    if let Err(err) = open_uri::open_directory(&WindowIdentifier::default(), &file).await{
                        warn!("Could not show the containing folder: {}", err.to_string());
                        inapp_notification(i18n("Could not show the containing folder"));
                    }
                },
                Err(err) => {
                    warn!("Could not open file: {}", err.to_string());
                    inapp_notification(i18n("Could not open file"));
                }
            }
        };
        spawn!(fut);
    }));

    // Disable `open` action if we're connected with a remote session
    // since we can't open files on non reachable filesystems
    let current_connection = FrgConnectionManager::default().current_connection();
    current_connection.connect_notify_local(
        Some("is_fragments"),
        clone!(@weak torrent, @weak action => move |_, _|{
            update_open_action(&torrent, &action);
        }),
    );

    // Disable `open` action if the torrent isn't downloaded yet
    torrent.connect_notify_local(
        Some("downloaded"),
        clone!(@weak torrent, @weak action => move |_, _|{
            update_open_action(&torrent, &action);
        }),
    );
    update_open_action(&torrent, &action);

    actions.add_action(&action);
}

fn update_status_action(
    torrent: &TrTorrent,
    continue_action: &gio::SimpleAction,
    pause_action: &gio::SimpleAction,
) {
    match torrent.status() {
        TrTorrentStatus::Stopped => {
            continue_action.set_enabled(true);
            pause_action.set_enabled(false);
        }
        _ => {
            continue_action.set_enabled(false);
            pause_action.set_enabled(true);
        }
    }
}

fn update_queue_action(
    torrent: &TrTorrent,
    queue_up_action: &gio::SimpleAction,
    queue_down_action: &gio::SimpleAction,
) {
    let enable = match torrent.status() {
        TrTorrentStatus::DownloadWait => true,
        _ => false,
    };

    queue_up_action.set_enabled(enable);
    queue_down_action.set_enabled(enable);
}

fn update_open_action(torrent: &TrTorrent, action: &gio::SimpleAction) {
    let current_connection = FrgConnectionManager::default().current_connection();
    let is_fragments = current_connection.is_fragments();
    let is_downloaded = torrent.size() == torrent.downloaded();

    action.set_enabled(is_fragments && is_downloaded);
}

fn move_queue(down: bool, torrent: TrTorrent) {
    let fut = clone!(@weak torrent => async move {
        let pos = if down{
            torrent.download_queue_position() + 1
        }else{
            torrent.download_queue_position() - 1
        };
        torrent.set_download_queue_position(pos).await.expect("Unable to set download queue position");
    });
    spawn!(fut);
}

pub fn show_remove_torrent_dialog(
    torrent: &TrTorrent,
    window: &gtk::Window,
    close_on_torrent_remove: bool,
) {
    let dialog = gtk::MessageDialog::new(
        Some(window),
        gtk::DialogFlags::MODAL,
        gtk::MessageType::Question,
        gtk::ButtonsType::OkCancel,
        &i18n("Remove Torrent?"),
    );

    dialog.set_secondary_text(Some(&i18n(
        "Once removed, continuing the transfer will require the torrent file or magnet link.",
    )));

    let message_area = dialog.message_area().downcast::<gtk::Box>().unwrap();
    let check_button = gtk::CheckButton::with_label(&i18n("Remove downloaded data as well"));
    message_area.append(&check_button);

    dialog.connect_response(
        clone!(@strong dialog, @weak window, @strong close_on_torrent_remove, @weak torrent, @weak check_button => move |_ , resp| {
            if resp == gtk::ResponseType::Ok {
                let fut = async move {
                    torrent.remove(check_button.is_active()).await.expect("Unable to remove torrent");
                };

                if close_on_torrent_remove{
                    window.hide();
                    window.destroy();
                }

                spawn!(fut);
            }

            dialog.close();
        }),
    );

    dialog.show();
}
