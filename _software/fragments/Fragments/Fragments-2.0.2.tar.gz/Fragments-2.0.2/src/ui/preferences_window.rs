// Fragments - preferences_window.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use adw::prelude::*;
use adw::subclass::prelude::*;
use ashpd::desktop::open_uri;
use ashpd::WindowIdentifier;
use glib::{clone, ParamSpec, ParamSpecObject};
use gtk::glib;
use gtk::subclass::prelude::*;
use gtk::CompositeTemplate;
use gtk::{FileChooserAction, FileChooserNative, ResponseType};
use once_cell::sync::Lazy;

use crate::backend::FrgConnectionManager;
use crate::i18n::{i18n, i18n_f};
use crate::settings::{settings_manager, Key};
use crate::ui::FrgApplicationWindow;
use crate::utils;

mod imp {
    use super::*;
    use glib::subclass;
    use gtk::glib::ParamFlags;

    #[derive(Default, Debug, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/preferences_window.ui")]
    pub struct FrgPreferencesWindow {
        #[template_child]
        pub remote_notice_group: TemplateChild<adw::PreferencesGroup>,
        #[template_child]
        pub remote_notice_row: TemplateChild<adw::ActionRow>,

        // General page
        #[template_child]
        pub appearance_group: TemplateChild<adw::PreferencesGroup>,
        #[template_child]
        pub dark_theme_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub notifications_downloaded_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub notifications_new_torrent_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub remote_access_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub open_webinterface_button: TemplateChild<gtk::Button>,

        // Downloading page
        #[template_child]
        pub download_dir_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub download_dir_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub incomplete_dir_expander: TemplateChild<adw::ExpanderRow>,
        #[template_child]
        pub incomplete_dir_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub incomplete_dir_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub download_queue_expander: TemplateChild<adw::ExpanderRow>,
        #[template_child]
        pub download_queue_size_spinbutton: TemplateChild<gtk::SpinButton>,
        #[template_child]
        pub start_added_torrents_switch: TemplateChild<adw::ActionRow>,

        // Network page
        #[template_child]
        pub port_spinbutton: TemplateChild<gtk::SpinButton>,
        #[template_child]
        pub random_port_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub port_forwarding_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub port_test_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub port_test_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub max_peers_torrent_spinbutton: TemplateChild<gtk::SpinButton>,
        #[template_child]
        pub max_peers_overall_spinbutton: TemplateChild<gtk::SpinButton>,
        #[template_child]
        pub encryption_comborow: TemplateChild<adw::ComboRow>,

        pub connection_manager: FrgConnectionManager,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgPreferencesWindow {
        const NAME: &'static str = "FrgPreferencesWindow";
        type ParentType = adw::PreferencesWindow;
        type Type = super::FrgPreferencesWindow;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgPreferencesWindow {
        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecObject::new(
                    "connection-manager",
                    "Connection manager",
                    "Connection manager",
                    FrgConnectionManager::static_type(),
                    ParamFlags::READABLE,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "connection-manager" => self.connection_manager.to_value(),
                _ => unimplemented!(),
            }
        }

        fn constructed(&self, obj: &Self::Type) {
            let window = FrgApplicationWindow::default();
            obj.set_transient_for(Some(&window));

            obj.setup_signals();
            obj.setup_widgets();

            self.parent_constructed(obj);
        }
    }

    impl WidgetImpl for FrgPreferencesWindow {}

    impl WindowImpl for FrgPreferencesWindow {}

    impl AdwWindowImpl for FrgPreferencesWindow {}

    impl PreferencesWindowImpl for FrgPreferencesWindow {}
}

glib::wrapper! {
    pub struct FrgPreferencesWindow(
        ObjectSubclass<imp::FrgPreferencesWindow>)
        @extends gtk::Widget, gtk::Window, adw::Window, adw::PreferencesWindow;

}

impl FrgPreferencesWindow {
    pub fn new() -> Self {
        glib::Object::new::<FrgPreferencesWindow>(&[]).unwrap()
    }

    fn setup_widgets(&self) {
        let imp = imp::FrgPreferencesWindow::from_instance(self);

        let manager = adw::StyleManager::default();
        let support_darkmode = manager.system_supports_color_schemes();
        imp.appearance_group.set_visible(!support_darkmode);

        self.update_paths();
        self.update_remote_buttons();
    }

    fn setup_signals(&self) {
        let imp = imp::FrgPreferencesWindow::from_instance(self);
        let client = imp.connection_manager.client();
        let session = client.session();

        // We show/hide few widgets depending on the connection type (remote/local)
        imp.connection_manager.connect_notify_local(
            Some("current-connection"),
            clone!(@weak self as this => move |_, _|{
                this.update_remote_buttons();
            }),
        );

        //
        // General page
        //
        settings_manager::bind_property(Key::DarkMode, &*imp.dark_theme_switch, "active");
        settings_manager::bind_property(
            Key::EnableNotificationsNewTorrent,
            &*imp.notifications_new_torrent_switch,
            "active",
        );
        settings_manager::bind_property(
            Key::EnableNotificationsDownloaded,
            &*imp.notifications_downloaded_switch,
            "active",
        );
        settings_manager::bind_property(Key::RemoteAccess, &*imp.remote_access_switch, "active");
        imp.remote_access_switch.connect_state_set(|switch, _| {
            settings_manager::set_boolean(Key::RemoteAccess, switch.is_active());
            switch.set_sensitive(false);

            let fut = clone!(@weak switch => async move {
                if let Err(err) = FrgConnectionManager::default().restart_daemon().await{
                    utils::inapp_notification(i18n("Unable to restart Transmission daemon"));
                    warn!("Unable to restart Transmission daemon: {}", err.to_string());
                }

                switch.set_sensitive(true);
            });
            spawn!(fut);
            glib::signal::Inhibit(false)
        });
        imp.open_webinterface_button.connect_clicked(|_| {
            let fut = async move {
                let link = "http://127.0.0.1:9091/".to_string();
                if let Err(err) =
                    open_uri::open_uri(&WindowIdentifier::default(), &link, false, false).await
                {
                    debug!("Unable to open webinterface: {:?}", err);
                    utils::inapp_notification("Unable to open webinterface");
                }
            };
            spawn!(fut);
        });

        //
        // Downloading page
        //
        client.connect_notify_local(
            Some("is-connected"),
            clone!(@weak self as this => move |_, _|{
                this.update_paths();
            }),
        );

        session.connect_notify_local(
            Some("download-dir"),
            glib::clone!(@weak self as this => move |_, _| {
                this.update_paths();
            }),
        );

        imp.download_dir_button
            .connect_clicked(glib::clone!(@weak self as this => move |_| {
                this.filechooser(&i18n("Select Download Directory"), "download-dir".into());
            }));

        session
            .bind_property(
                "incomplete-dir-enabled",
                &*imp.incomplete_dir_expander,
                "enable-expansion",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session.connect_notify_local(
            Some("incomplete-dir"),
            glib::clone!(@weak self as this => move |_, _| {
                this.update_paths();
            }),
        );

        imp.incomplete_dir_button
            .connect_clicked(glib::clone!(@weak self as this => move |_| {
                this.filechooser(&i18n("Select Incomplete Directory"), "incomplete-dir".into());
            }));

        session
            .bind_property(
                "download-queue-enabled",
                &*imp.download_queue_expander,
                "enable-expansion",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property(
                "download-queue-size",
                &*imp.download_queue_size_spinbutton,
                "value",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property(
                "start-added-torrents",
                &*imp.start_added_torrents_switch,
                "active",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        //
        // Network page
        //
        session
            .bind_property("peer-port", &*imp.port_spinbutton, "value")
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property(
                "peer-port-random-on-start",
                &*imp.random_port_switch,
                "active",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property(
                "port-forwarding-enabled",
                &*imp.port_forwarding_switch,
                "active",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property(
                "peer-limit-per-torrent",
                &*imp.max_peers_torrent_spinbutton,
                "value",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property(
                "peer-limit-global",
                &*imp.max_peers_overall_spinbutton,
                "value",
            )
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        session
            .bind_property("encryption", &*imp.encryption_comborow, "selected")
            .flags(glib::BindingFlags::SYNC_CREATE | glib::BindingFlags::BIDIRECTIONAL)
            .build();

        imp.port_test_button
            .connect_clicked(clone!(@weak self as this => move |_|{
                let fut = async move {
                    this.port_test().await;
                };
                spawn!(fut);
            }));
    }

    async fn port_test(&self) {
        let imp = imp::FrgPreferencesWindow::from_instance(self);
        let client = imp.connection_manager.client();

        imp.port_test_button.set_sensitive(false);
        let msg = i18n("Testing…");
        imp.port_test_label.set_label(&msg);

        imp.port_test_label.remove_css_class("heading");
        imp.port_test_label.remove_css_class("error");
        imp.port_test_label.remove_css_class("success");

        let msg = match client.test_port().await {
            Ok(succeeded) => {
                if succeeded {
                    imp.port_test_label.add_css_class("success");
                    i18n("Port is open. You can communicate with other peers.")
                } else {
                    imp.port_test_label.add_css_class("error");
                    i18n("Port is closed. Communication with other peers is limited.\nCheck your router or firewall if port forwarding is enabled for your computer. ")
                }
            }
            Err(_) => {
                imp.port_test_label.add_css_class("error");
                i18n("Test failed. Make sure you are connected to the internet.")
            }
        };

        imp.port_test_label.add_css_class("heading");
        imp.port_test_label.set_label(&msg);
        imp.port_test_button.set_sensitive(true);
    }

    fn filechooser(&self, label: &str, prop_name: String) {
        let imp = imp::FrgPreferencesWindow::from_instance(&self);
        let session = imp.connection_manager.client().session();

        let dialog = FileChooserNative::new(
            Some(label),
            Some(self),
            FileChooserAction::SelectFolder,
            Some(&i18n("_Select")),
            Some(&i18n("_Cancel")),
        );

        dialog.connect_response(
            glib::clone!(@strong dialog, @weak self as this, @strong prop_name => move |_, resp| {
                dialog.destroy();
                if resp == ResponseType::Accept {
                    if let Some(folder) = dialog.file() {
                        if let Some(path) = folder.path() {
                            if let Some(path_string) = path.to_str() {
                                debug!("Selected direcotry: {}", path_string);
                                session.set_property(prop_name.as_str(), folder);
                                this.update_paths();
                            }
                        }
                    } else {
                        warn!("Selected directory could not be accessed {:?}", dialog.file());
                    }
                }
            }),
        );

        dialog.show();
    }

    fn update_paths(&self) {
        let imp = imp::FrgPreferencesWindow::from_instance(&self);
        let session = imp.connection_manager.client().session();

        if let Some(file) = session.download_dir() {
            let download_dir = file.basename().unwrap().to_str().unwrap().to_string();
            imp.download_dir_label.set_label(&download_dir);
        }
        if let Some(file) = session.incomplete_dir() {
            let incomplete_dir = file.basename().unwrap().to_str().unwrap().to_string();
            imp.incomplete_dir_label.set_label(&incomplete_dir);
        }
    }

    fn update_remote_buttons(&self) {
        let imp = imp::FrgPreferencesWindow::from_instance(&self);
        let is_fragments = imp.connection_manager.current_connection().is_fragments();
        let title = imp.connection_manager.current_connection().title();

        imp.download_dir_button.set_sensitive(is_fragments);
        imp.incomplete_dir_button.set_sensitive(is_fragments);

        imp.remote_notice_group.set_visible(!is_fragments);
        imp.remote_notice_row
            .set_title(&i18n_f("You are connected with “{}”", &[&title]));
    }
}
