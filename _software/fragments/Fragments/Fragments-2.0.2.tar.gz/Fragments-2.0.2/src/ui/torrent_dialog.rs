// Fragments - torrent_dialog.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use adw::subclass::prelude::*;
use glib::{clone, ParamFlags, ParamSpec, ParamSpecObject};
use gtk::subclass::prelude::*;
use gtk::{gio, glib, prelude::*, CompositeTemplate};
use once_cell::unsync::OnceCell;
use transmission_gobject::{TrTorrent, TrTorrentStatus};

use std::convert::TryInto;

use crate::app::FrgApplication;
use crate::i18n::ni18n_f;
use crate::ui::FrgApplicationWindow;
use crate::utils;

mod imp {
    use super::*;
    use glib::subclass;

    #[derive(Debug, Default, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/torrent_dialog.ui")]
    pub struct FrgTorrentDialog {
        #[template_child]
        pub headerbar: TemplateChild<gtk::HeaderBar>,
        #[template_child]
        pub dialog_title: TemplateChild<adw::WindowTitle>,
        #[template_child]
        pub scrolled_window: TemplateChild<gtk::ScrolledWindow>,
        #[template_child]
        pub mime_type_image: TemplateChild<gtk::Image>,
        #[template_child]
        pub torrent_name_label: TemplateChild<gtk::Label>,

        #[template_child]
        pub progressbar_downloaded_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub progressbar_total_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub progressbar_eta_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub progress_bar: TemplateChild<gtk::ProgressBar>,

        #[template_child]
        pub button_stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub pause_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub continue_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub open_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub more_button: TemplateChild<gtk::MenuButton>,

        #[template_child]
        pub download_image: TemplateChild<gtk::Image>,
        #[template_child]
        pub upload_image: TemplateChild<gtk::Image>,
        #[template_child]
        pub download_speed_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub upload_speed_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub seeders_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub leechers_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub downloaded_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub uploaded_label: TemplateChild<gtk::Label>,

        pub torrent: OnceCell<TrTorrent>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgTorrentDialog {
        const NAME: &'static str = "FrgTorrentDialog";
        type ParentType = adw::Window;
        type Type = super::FrgTorrentDialog;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgTorrentDialog {
        fn properties() -> &'static [ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecObject::new(
                    "torrent",
                    "torrent",
                    "torrent",
                    TrTorrent::static_type(),
                    ParamFlags::READWRITE | ParamFlags::CONSTRUCT_ONLY,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(
            &self,
            _obj: &Self::Type,
            _id: usize,
            value: &glib::Value,
            pspec: &ParamSpec,
        ) {
            match pspec.name() {
                "torrent" => {
                    let torrent = value.get().unwrap();
                    let _ = self.torrent.set(torrent);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "torrent" => self.torrent.get().to_value(),
                _ => unimplemented!(),
            }
        }

        fn constructed(&self, obj: &Self::Type) {
            obj.setup_signals();
            obj.setup_widgets();

            utils::install_torrent_actions(
                &obj.torrent(),
                obj.clone().upcast(),
                obj.clone().upcast(),
                true,
            );

            self.parent_constructed(obj);
        }
    }

    impl WidgetImpl for FrgTorrentDialog {}

    impl WindowImpl for FrgTorrentDialog {}

    impl AdwWindowImpl for FrgTorrentDialog {}
}

glib::wrapper! {
    pub struct FrgTorrentDialog(ObjectSubclass<imp::FrgTorrentDialog>)
        @extends gtk::Widget, gtk::Window, adw::Window;
}

impl FrgTorrentDialog {
    pub fn new(torrent: &TrTorrent) -> Self {
        let dialog: Self = glib::Object::new(&[("torrent", torrent)]).unwrap();

        let window = FrgApplicationWindow::default();
        dialog.set_transient_for(Some(&window));

        let app = FrgApplication::default();
        app.add_window(&window);

        dialog
    }

    fn setup_widgets(&self) {
        let imp = imp::FrgTorrentDialog::from_instance(self);

        // "More" menu button
        let builder = gtk::Builder::from_resource("/de/haeckerfelix/Fragments/gtk/torrent_menu.ui");
        let menu: gio::MenuModel = builder.object("torrent_more_menu").unwrap();
        imp.more_button.set_menu_model(Some(&menu));

        self.bind_property("name", imp.dialog_title.get(), "title");
        self.bind_property("name", imp.torrent_name_label.get(), "label");
        self.bind_property("progress", imp.progress_bar.get(), "fraction");
        self.bind_property("leechers", imp.leechers_label.get(), "label");
        utils::set_mime_type_image(
            &self.torrent().primary_mime_type(),
            &imp.mime_type_image.get(),
        );

        self.torrent().connect_notify_local(
            None,
            clone!(@weak self as this => move |_, _| {
                this.update_labels();
                this.update_widgets();
            }),
        );

        self.update_labels();
        self.update_widgets();
    }

    fn setup_signals(&self) {
        let imp = imp::FrgTorrentDialog::from_instance(self);

        imp.scrolled_window.vadjustment().connect_value_notify(
            clone!(@weak self as this => move |adj|{
                let imp = imp::FrgTorrentDialog::from_instance(&this);
                if adj.value() < 210.0 {
                    imp.headerbar.add_css_class("hidden");
                    imp.dialog_title.set_visible(false);
                }else {
                    imp.headerbar.remove_css_class("hidden");
                    imp.dialog_title.set_visible(true);
                }
            }),
        );

        imp.torrent_name_label.connect_label_notify(|label| {
            let large_title = !(label.text().len() > 25);

            if large_title {
                label.remove_css_class("title-2");
                label.add_css_class("title-1");
            } else {
                label.remove_css_class("title-1");
                label.add_css_class("title-2");
            }
        });
    }

    pub fn torrent(&self) -> TrTorrent {
        self.property("torrent")
    }

    fn update_labels(&self) {
        let imp = imp::FrgTorrentDialog::from_instance(self);
        let torrent = self.torrent();

        let eta = utils::eta_text(&self.torrent());
        let total = utils::format_size(torrent.size());
        let downloaded = utils::format_size(torrent.downloaded());
        let uploaded = utils::format_size(torrent.uploaded());
        let download_speed = utils::format_speed(torrent.download_speed());
        let upload_speed = utils::format_speed(torrent.upload_speed());

        imp.progressbar_downloaded_label.set_text(&downloaded);
        imp.progressbar_total_label.set_text(&total);
        imp.progressbar_eta_label.set_text(&eta);

        imp.downloaded_label.set_text(&downloaded);
        imp.uploaded_label.set_text(&uploaded);
        imp.download_speed_label.set_text(&download_speed);
        imp.upload_speed_label.set_text(&upload_speed);

        let seeders = torrent.seeders().to_string();
        let seeders_active = torrent.seeders_active().to_string();
        // Translators: First {} corresponds to the number of seeders, second {} to the number of active seeders
        let seeders_text = ni18n_f(
            "{} ({} active)",
            "{} ({} active)",
            torrent.seeders_active().try_into().unwrap_or(0),
            &[&seeders, &seeders_active],
        );
        imp.seeders_label.set_text(&seeders_text);
    }

    fn update_widgets(&self) {
        let imp = imp::FrgTorrentDialog::from_instance(self);
        let torrent = self.torrent();

        let is_downloading = torrent.download_speed() != 0;
        let is_uploading = torrent.upload_speed() != 0;

        if is_downloading {
            imp.download_image.add_css_class("active");
        } else {
            imp.download_image.remove_css_class("active");
        }

        if is_uploading {
            imp.upload_image.add_css_class("active");
        } else {
            imp.upload_image.remove_css_class("active");
        }

        let button_widget = match self.torrent().status() {
            TrTorrentStatus::Stopped => imp.continue_button.get(),
            _ => imp.pause_button.get(),
        };
        imp.button_stack.set_visible_child(&button_widget);
    }

    fn bind_property<T: IsA<gtk::Widget>>(
        &self,
        prop_name: &str,
        widget: T,
        widget_prop_name: &str,
    ) {
        self.torrent()
            .bind_property(prop_name, &widget, widget_prop_name)
            .flags(glib::BindingFlags::SYNC_CREATE)
            .build();
    }
}
