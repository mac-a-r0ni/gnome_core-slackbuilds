// Fragments - add_connection_dialog.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use adw::subclass::prelude::*;
use glib::clone;
use gtk::glib;
use gtk::prelude::*;
use gtk::subclass::prelude::*;
use gtk::CompositeTemplate;
use transmission_gobject::TrClient;

use std::cell::{Cell, RefCell};

use crate::app::FrgApplication;
use crate::backend::{FrgConnection, FrgConnectionManager};
use crate::i18n::i18n_f;
use crate::ui::FrgApplicationWindow;
use crate::utils;

mod imp {
    use super::*;
    use glib::subclass;

    #[derive(Debug, Default, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/add_connection_dialog.ui")]
    pub struct FrgAddConnectionDialog {
        #[template_child]
        pub stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub title_entry: TemplateChild<gtk::Entry>,
        #[template_child]
        pub host_entry: TemplateChild<gtk::Entry>,
        #[template_child]
        pub port_spinbutton: TemplateChild<gtk::SpinButton>,
        #[template_child]
        pub path_entry: TemplateChild<gtk::Entry>,
        #[template_child]
        pub ssl_switch: TemplateChild<gtk::Switch>,
        #[template_child]
        pub connect_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub error_label: TemplateChild<gtk::Label>,

        pub title_ok: Cell<bool>,
        pub address_ok: Cell<bool>,
        pub address: RefCell<String>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgAddConnectionDialog {
        const NAME: &'static str = "FrgAddConnectionDialog";
        type ParentType = gtk::Dialog;
        type Type = super::FrgAddConnectionDialog;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
            Self::Type::bind_template_callbacks(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgAddConnectionDialog {}

    impl WidgetImpl for FrgAddConnectionDialog {}

    impl WindowImpl for FrgAddConnectionDialog {}

    impl DialogImpl for FrgAddConnectionDialog {}
}

glib::wrapper! {
    pub struct FrgAddConnectionDialog(ObjectSubclass<imp::FrgAddConnectionDialog>)
        @extends gtk::Widget, gtk::Window, adw::Window;
}

#[gtk::template_callbacks]
impl FrgAddConnectionDialog {
    pub fn new() -> Self {
        let dialog: Self = glib::Object::new(&[("use-header-bar", &1)]).unwrap();

        let window = FrgApplicationWindow::default();
        dialog.set_transient_for(Some(&window));

        dialog
    }

    fn add_connection(&self, connection: FrgConnection) {
        let cm = FrgConnectionManager::default();
        let app = FrgApplication::default();

        cm.connections().append(&connection);
        app.activate_action("set-connection", Some(&connection.uuid().to_variant()));
        self.hide();
    }

    #[template_callback]
    fn connect_button_clicked(&self) {
        let fut = clone!(@weak self as this => async move {
            let imp = imp::FrgAddConnectionDialog::from_instance(&this);
            let title = imp.title_entry.text();
            let address = imp.address.borrow();

            let connection = FrgConnection::new(&title, &address);

            imp.stack.set_visible_child_name("loading");
            imp.connect_button.set_sensitive(false);

            let res = TrClient::test_connectivity(connection.address(), None).await;
            match res{
                Ok(_) => this.add_connection(connection),
                Err(ref err) => {
                    // Skip "Unauthorized" errors since we can handle those
                    if utils::is_unauthorized(&res){
                        this.add_connection(connection);
                    }else{
                        let msg = i18n_f("Could not connect with “{}”:\n{}", &[&imp.address.borrow(), &err.to_string()]);

                        imp.error_label.set_visible(true);
                        imp.error_label.set_text(&msg);

                        imp.stack.set_visible_child_name("input");
                        imp.connect_button.set_sensitive(true);
                    }
                }
            }
        });
        spawn!(fut);
    }

    #[template_callback]
    fn validate_title(&self) {
        let imp = imp::FrgAddConnectionDialog::from_instance(self);

        if imp.title_entry.text().is_empty() {
            imp.title_entry.add_css_class("error");
            imp.title_ok.set(false);
        } else {
            imp.title_entry.remove_css_class("error");
            imp.title_ok.set(true);
        }

        self.update_connect_button();
    }

    #[template_callback]
    fn validate_address(&self) {
        let imp = imp::FrgAddConnectionDialog::from_instance(self);

        let host = imp.host_entry.text();
        let port = imp.port_spinbutton.value();
        let path = imp.path_entry.text();
        let is_ssl = imp.ssl_switch.is_active();

        let address = if is_ssl {
            format!("https://{}:{}{}", host, port, path)
        } else {
            format!("http://{}:{}{}", host, port, path)
        };
        *imp.address.borrow_mut() = address.to_string();

        let valid_address = url::Url::parse(&address).is_ok();

        if !imp.host_entry.text().is_empty() && valid_address {
            imp.host_entry.remove_css_class("error");
            imp.address_ok.set(true);
        } else {
            // Don't recolor entry if it is empty
            if !imp.host_entry.text().is_empty() {
                imp.host_entry.add_css_class("error");
            } else {
                imp.host_entry.remove_css_class("error");
            }

            imp.address_ok.set(false);
        }

        self.update_connect_button();
    }

    fn update_connect_button(&self) {
        let imp = imp::FrgAddConnectionDialog::from_instance(self);

        let sensitive = imp.title_ok.get() && imp.address_ok.get();
        imp.connect_button.set_sensitive(sensitive);
    }
}
