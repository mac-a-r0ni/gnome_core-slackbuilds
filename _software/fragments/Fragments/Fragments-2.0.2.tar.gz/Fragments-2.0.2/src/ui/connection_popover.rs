// Fragments - connection_popover.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use glib::clone;
use gtk::glib;
use gtk::prelude::*;
use gtk::subclass::prelude::*;

use crate::app::FrgApplication;
use crate::backend::{FrgConnection, FrgConnectionManager};
use crate::ui::FrgConnectionRow;

mod imp {
    use gtk::CompositeTemplate;

    use super::*;
    use glib::subclass;

    #[derive(Debug, CompositeTemplate, Default)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/connection_popover.ui")]
    pub struct FrgConnectionPopover {
        #[template_child]
        pub listbox: TemplateChild<gtk::ListBox>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgConnectionPopover {
        const NAME: &'static str = "FrgConnectionPopover";
        type ParentType = gtk::Popover;
        type Type = super::FrgConnectionPopover;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgConnectionPopover {
        fn constructed(&self, obj: &Self::Type) {
            obj.setup_signals();
            obj.update_ui();
            self.parent_constructed(obj);
        }
    }

    impl WidgetImpl for FrgConnectionPopover {}

    impl PopoverImpl for FrgConnectionPopover {}
}

glib::wrapper! {
    pub struct FrgConnectionPopover(
        ObjectSubclass<imp::FrgConnectionPopover>)
        @extends gtk::Widget, gtk::Popover;
}

impl FrgConnectionPopover {
    fn setup_signals(&self) {
        let imp = imp::FrgConnectionPopover::from_instance(self);
        let cm = FrgConnectionManager::default();

        imp.listbox
            .connect_row_activated(clone!(@weak self as this => move |_, row|{
                let row = row.downcast_ref::<FrgConnectionRow>().unwrap();
                let app = FrgApplication::default();

                app.activate_action("set-connection", Some(&row.connection().uuid().to_variant()));
                this.hide();
            }));

        imp.listbox
            .bind_model(Some(&cm.connections()), |connection| {
                FrgConnectionRow::new(&connection.downcast_ref::<FrgConnection>().unwrap()).upcast()
            });

        cm.connect_notify_local(
            Some("current-connection"),
            clone!(@weak self as this => move |_,_|{
                this.update_ui();
            }),
        );

        cm.client().connect_notify_local(
            Some("is-busy"),
            clone!(@weak self as this => move |client,_|{
                // Don't allow changing the active connection
                // when the client is still busy establishing a connection
                this.set_sensitive(!client.is_busy());
            }),
        );

        cm.connections()
            .connect_items_changed(clone!(@weak self as this => move |_,_,_,_|{
                this.update_ui();
            }));
    }

    fn update_ui(&self) {
        let imp = imp::FrgConnectionPopover::from_instance(self);
        let cm = FrgConnectionManager::default();

        let mut i = 0;
        let current = cm.current_connection();

        while let Some(row) = imp.listbox.row_at_index(i) {
            let row = row.downcast::<FrgConnectionRow>().unwrap();
            row.set_selected(row.connection() == current);
            i += 1;
        }
    }
}
