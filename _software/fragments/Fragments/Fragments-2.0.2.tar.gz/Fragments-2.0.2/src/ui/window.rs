// Fragments - window.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use adw::subclass::prelude::AdwApplicationWindowImpl;
use glib::{clone, subclass};
use gtk::subclass::prelude::*;
use gtk::CompositeTemplate;
use gtk::{gdk, gio, glib, prelude::*};
use magnet_uri::MagnetURI;
use transmission_gobject::TrTorrent;

use std::str::FromStr;

use crate::app::FrgApplication;
use crate::backend::FrgConnectionManager;
use crate::config;
use crate::i18n::{i18n, i18n_f};
use crate::settings::{settings_manager, Key};
use crate::ui::{FrgConnectionBox, FrgConnectionPopover, FrgTorrentGroup, FrgTorrentPage};
use crate::utils;

mod imp {
    use super::*;

    #[derive(Default, Debug, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/window.ui")]
    pub struct FrgApplicationWindow {
        #[template_child]
        pub headerbar: TemplateChild<gtk::HeaderBar>,
        #[template_child]
        pub window_title: TemplateChild<adw::WindowTitle>,
        #[template_child]
        pub app_menu_button: TemplateChild<gtk::MenuButton>,
        #[template_child]
        pub connection_menu: TemplateChild<gtk::MenuButton>,
        #[template_child]
        pub connection_box: TemplateChild<FrgConnectionBox>,
        #[template_child]
        pub toast_overlay: TemplateChild<adw::ToastOverlay>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgApplicationWindow {
        const NAME: &'static str = "FrgApplicationWindow";
        type ParentType = adw::ApplicationWindow;
        type Type = super::FrgApplicationWindow;

        fn class_init(klass: &mut Self::Class) {
            FrgTorrentPage::static_type();
            FrgTorrentGroup::static_type();
            FrgConnectionPopover::static_type();
            FrgConnectionBox::static_type();
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgApplicationWindow {
        fn constructed(&self, obj: &Self::Type) {
            obj.setup_widgets();
            obj.setup_signals();
            self.parent_constructed(obj);
        }
    }

    impl WidgetImpl for FrgApplicationWindow {}

    impl WindowImpl for FrgApplicationWindow {
        fn close_request(&self, window: &Self::Type) -> glib::signal::Inhibit {
            debug!("Saving window geometry.");
            let (width, height) = window.default_size();

            settings_manager::set_integer(Key::WindowWidth, width);
            settings_manager::set_integer(Key::WindowHeight, height);

            let fut = clone!(@weak window => async move {
                window.hide();

                // Wait till transmission daemon is stopped
                FrgConnectionManager::default().stop_daemon()
                    .await
                    .expect("Unable to stop the transmission daemon");

                FrgApplication::default().quit();
            });
            spawn!(fut);

            glib::signal::Inhibit(true)
        }
    }

    impl ApplicationWindowImpl for FrgApplicationWindow {}

    impl AdwApplicationWindowImpl for FrgApplicationWindow {}
}

// Wrap FrgApplicationWindow into a usable gtk-rs object
glib::wrapper! {
    pub struct FrgApplicationWindow(
        ObjectSubclass<imp::FrgApplicationWindow>)
        @extends gtk::Widget, gtk::Window, gtk::ApplicationWindow, adw::ApplicationWindow, @implements gio::ActionMap, gio::ActionGroup;
}

// FrgApplicationWindow implementation itself
impl FrgApplicationWindow {
    pub fn new(app: &FrgApplication) -> Self {
        glib::Object::new::<FrgApplicationWindow>(&[("application", app)]).unwrap()
    }

    fn setup_widgets(&self) {
        // Set default size
        let width = settings_manager::get_integer(Key::WindowWidth);
        let height = settings_manager::get_integer(Key::WindowHeight);
        self.set_default_size(width, height);

        // Development style
        if config::PROFILE == "development" {
            self.add_css_class("devel");
        }
    }

    fn setup_signals(&self) {
        let cm = FrgConnectionManager::default();

        // Recolor headerbar purple for remote connections
        cm.connect_notify_local(
            Some("current-connection"),
            clone!(@weak self as this => move |manager, _|{
                let imp = imp::FrgApplicationWindow::from_instance(&this);
                if !manager.current_connection().is_fragments(){
                    let subtitle = i18n_f("Remote control \"{}\"", &[&manager.current_connection().title()]);
                    imp.window_title.set_subtitle(&subtitle);
                    imp.headerbar.add_css_class("remote");
                }else{
                    imp.window_title.set_subtitle("");
                    imp.headerbar.style_context().remove_class("remote");
                }
            }),
        );

        // Show connection button if we have more than the standard local connection
        cm.connections()
            .connect_items_changed(clone!(@weak self as this => move |model,_,_,_|{
                let imp = imp::FrgApplicationWindow::from_instance(&this);
                let show = model.n_items() > 1;
                imp.connection_menu.set_visible(show);
            }));

        // Check clipboard content for magnet links
        self.connect_is_active_notify(move |window| {
            if window.is_active() {
                let display = gdk::Display::default().unwrap();
                let clipboard = display.clipboard();

                let callback = clone!(@weak window, @weak clipboard => move |content: Result<Option<glib::GString>, glib::Error>| {
                    if let Ok(Some(text)) = content {
                        if let Ok(magnet_link) = MagnetURI::from_str(&text){
                            let fallback = String::new();
                            let info_hash = magnet_link.info_hash().unwrap_or(&fallback);
                            let cm = FrgConnectionManager::default();

                            if cm.client().torrents().torrent_by_hash(info_hash.to_string()).is_none(){
                                debug!("Detected new magent link: {}", &text);
                                window.magnet_link_notification(&text, magnet_link.name());
                            }else{
                                debug!("Ignore magnet link, torrent is already added.");
                            }
                        }
                    }
                });
                clipboard.read_text_async(gio::Cancellable::NONE, callback);
            }
        });

        // torrent-added notification
        cm.client().connect_local("torrent-added", false, clone!(@weak self as this => @default-return None, move |torrent|{
            if settings_manager::get_boolean(Key::EnableNotificationsNewTorrent){
                let torrent: TrTorrent = torrent[1].get().unwrap();
                utils::system_notification(i18n("New torrent added"), torrent.name(), Some("folder-download-symbolic"));
            }
            None
        }));

        // torrent-downloaded notification
        cm.client().connect_local("torrent-downloaded", false, clone!(@weak self as this => @default-return None, move |torrent|{
            if settings_manager::get_boolean(Key::EnableNotificationsDownloaded){
                let torrent: TrTorrent = torrent[1].get().unwrap();
                utils::system_notification(i18n("Torrent completely downloaded"), torrent.name(), Some("folder-download-symbolic"));
            }
            None
        }));
    }

    pub fn inapp_notification(&self, text: &str) {
        let imp = imp::FrgApplicationWindow::from_instance(self);
        let toast = adw::Toast::new(text);
        imp.toast_overlay.add_toast(&toast);
    }

    pub fn magnet_link_notification(&self, magnet_link: &str, title: Option<&str>) {
        let imp = imp::FrgApplicationWindow::from_instance(self);

        let text = match title {
            Some(name) => i18n_f("Add magnet link “{}” from clipboard?", &[&name]),
            None => i18n("Add magnet link from clipboard?"),
        };

        let toast = adw::Toast::new(&text);
        toast.set_button_label(Some(&i18n("_Add")));
        toast.set_action_name(Some("app.add-magnet"));
        toast.set_action_target_value(Some(&magnet_link.to_variant()));

        imp.toast_overlay.get().add_toast(&toast);
    }

    pub fn show_authentication(&self, failure: bool) {
        let imp = imp::FrgApplicationWindow::from_instance(self);
        imp.connection_box.show_authentication(failure);
    }

    pub fn show_connection_failure_message(&self, msg: &str) {
        let imp = imp::FrgApplicationWindow::from_instance(self);
        imp.connection_box.show_failure_message(msg.to_string());
    }
}

impl Default for FrgApplicationWindow {
    fn default() -> Self {
        FrgApplication::default()
            .active_window()
            .unwrap()
            .downcast()
            .unwrap()
    }
}
