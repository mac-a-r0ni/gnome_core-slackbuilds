// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use glib::{clone, ParamFlags, ParamSpec, ParamSpecObject};
use gtk::subclass::prelude::*;
use gtk::{gdk, gio, glib, prelude::*, CompositeTemplate};
use transmission_gobject::{TrTorrent, TrTorrentStatus};

use crate::i18n::i18n_f;
use crate::ui::FrgApplicationWindow;
use crate::utils;

mod imp {
    use super::*;
    use glib::subclass;
    use once_cell::sync::OnceCell;

    #[derive(Debug, CompositeTemplate, Default)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/torrent_row.ui")]
    pub struct FrgTorrentRow {
        #[template_child]
        pub torrent_name_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub description_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub eta_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub queue_position_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub progress_bar: TemplateChild<gtk::ProgressBar>,
        #[template_child]
        pub spinner: TemplateChild<gtk::Spinner>,
        #[template_child]
        pub queue_box: TemplateChild<gtk::Box>,
        #[template_child]
        pub index_stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub action_stack: TemplateChild<gtk::Stack>,

        pub popover_menu: OnceCell<gtk::PopoverMenu>,
        pub torrent: OnceCell<TrTorrent>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgTorrentRow {
        const NAME: &'static str = "FrgTorrentRow";
        type ParentType = gtk::ListBoxRow;
        type Type = super::FrgTorrentRow;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgTorrentRow {
        fn properties() -> &'static [ParamSpec] {
            use once_cell::sync::Lazy;
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecObject::new(
                    "torrent",
                    "torrent",
                    "torrent",
                    TrTorrent::static_type(),
                    ParamFlags::READWRITE | ParamFlags::CONSTRUCT_ONLY,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn set_property(
            &self,
            _obj: &Self::Type,
            _id: usize,
            value: &glib::Value,
            pspec: &ParamSpec,
        ) {
            match pspec.name() {
                "torrent" => {
                    let torrent = value.get().unwrap();
                    let _ = self.torrent.set(torrent);
                }
                _ => unimplemented!(),
            }
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "torrent" => self.torrent.get().to_value(),
                _ => unimplemented!(),
            }
        }

        fn constructed(&self, obj: &Self::Type) {
            obj.setup_widgets();
            obj.setup_signals();

            let window = FrgApplicationWindow::default();
            utils::install_torrent_actions(
                &obj.torrent(),
                obj.clone().upcast(),
                window.clone().upcast(),
                false,
            );

            self.parent_constructed(obj);
        }

        fn dispose(&self, _obj: &Self::Type) {
            self.popover_menu.get().unwrap().unparent();
        }
    }

    impl WidgetImpl for FrgTorrentRow {}

    impl ListBoxRowImpl for FrgTorrentRow {}
}

glib::wrapper! {
    pub struct FrgTorrentRow(
        ObjectSubclass<imp::FrgTorrentRow>)
        @extends gtk::Widget, gtk::ListBoxRow;
}

impl FrgTorrentRow {
    pub fn new(torrent: &TrTorrent) -> Self {
        glib::Object::new(&[("torrent", torrent)]).unwrap()
    }

    fn setup_widgets(&self) {
        let imp = imp::FrgTorrentRow::from_instance(&self);

        // Right-click popover menu
        let builder = gtk::Builder::from_resource("/de/haeckerfelix/Fragments/gtk/torrent_menu.ui");
        let menu: gio::MenuModel = builder.object("torrent_menu").unwrap();

        let popover_menu = gtk::PopoverMenu::from_model(Some(&menu));
        popover_menu.set_parent(self);

        // Theres a GTK glitch which causes that the row is going to stay active,
        // even after the gesture/click, but it won't happen if the popover has an arrow.
        //
        // https://gitlab.gnome.org/GNOME/gtk/-/issues/2877
        //
        // TODO: Remove the arrow again when the bug got fixed ^
        popover_menu.set_has_arrow(true);
        imp.popover_menu.set(popover_menu).unwrap();

        // Binding torrent values
        self.bind_property("name", imp.torrent_name_label.get(), "label");
        self.bind_property("progress", imp.progress_bar.get(), "fraction");

        self.torrent().connect_notify_local(
            None,
            clone!(@weak self as this => move |_, _| {
                this.update_labels();
                this.update_widgets();
            }),
        );

        self.update_labels();
        self.update_widgets();
    }

    fn setup_signals(&self) {
        // Shift+F10 / `Menu` button to open context menu
        let trigger = gtk::AlternativeTrigger::new(
            &gtk::KeyvalTrigger::new(gdk::Key::F10, gdk::ModifierType::SHIFT_MASK),
            &gtk::KeyvalTrigger::new(gdk::Key::Menu, gdk::ModifierType::empty()),
        );
        let action = gtk::CallbackAction::new(
            clone!(@weak self as this => @default-return true, move |_, _| {
                this.show_context_menu(None::<&gtk::Gesture>, 40.0, 40.0);
                true
            }),
        );
        let shortcut = gtk::Shortcut::new(Some(&trigger), Some(&action));

        let controller = gtk::ShortcutController::new();
        controller.add_shortcut(&shortcut);
        self.add_controller(&controller);

        // Right click to open context menu
        let controller = gtk::GestureClick::new();
        controller.set_button(gdk::BUTTON_SECONDARY);
        controller.connect_pressed(
            clone!(@weak self as this => move |c, _, x, y| this.show_context_menu(Some(c), x, y)),
        );
        self.add_controller(&controller);

        // Touch long-press to open context menu
        let controller = gtk::GestureLongPress::new();
        controller.set_touch_only(true);
        controller.connect_pressed(
            clone!(@weak self as this => move |c, x, y| this.show_context_menu(Some(c), x, y)),
        );
        self.add_controller(&controller);
    }

    pub fn torrent(&self) -> TrTorrent {
        self.property("torrent")
    }

    fn show_context_menu<G>(&self, controller: Option<&G>, x: f64, y: f64)
    where
        G: IsA<gtk::Gesture>,
    {
        let imp = imp::FrgTorrentRow::from_instance(&self);

        if let Some(controller) = controller {
            controller.set_state(gtk::EventSequenceState::Claimed);
        }

        let coords = gdk::Rectangle::new(x as i32, y as i32, 0, 0);

        imp.popover_menu
            .get()
            .unwrap()
            .set_pointing_to(Some(&coords));
        imp.popover_menu.get().unwrap().popup();
    }

    fn update_labels(&self) {
        let imp = imp::FrgTorrentRow::from_instance(self);
        let torrent = self.torrent();

        let eta = utils::eta_text(&self.torrent());
        let description = self.description_text();
        let pos = (torrent.download_queue_position() + 1).to_string();

        imp.eta_label.set_text(&eta);
        imp.description_label.set_text(&description);
        imp.queue_position_label.set_text(&pos);
    }

    fn update_widgets(&self) {
        let imp = imp::FrgTorrentRow::from_instance(self);

        imp.queue_box.set_visible(false);
        imp.spinner.set_spinning(false);
        self.remove_css_class("queued-torrent");

        let index_name: String;
        let action_name: String;

        match self.torrent().status() {
            TrTorrentStatus::Download => {
                index_name = "download".into();
                action_name = "pause".into();
            }
            TrTorrentStatus::DownloadWait => {
                index_name = "queued".into();
                action_name = "pause".into();

                self.add_css_class("queued-torrent");
                imp.queue_box.set_visible(true);
            }
            TrTorrentStatus::Check | TrTorrentStatus::CheckWait => {
                index_name = "check".into();
                action_name = "pause".into();

                self.add_css_class("queued-torrent");
                imp.spinner.set_spinning(true);
            }
            TrTorrentStatus::Stopped => {
                index_name = "stopped".into();
                action_name = "continue".into();

                self.add_css_class("queued-torrent");
            }
            TrTorrentStatus::Seed | TrTorrentStatus::SeedWait => {
                index_name = "upload".into();
                action_name = "remove".into();
            }
        }

        imp.index_stack.set_visible_child_name(&index_name);
        imp.action_stack.set_visible_child_name(&action_name);
    }

    fn description_text(&self) -> String {
        let torrent = self.torrent();

        let downloaded = utils::format_size(torrent.downloaded());
        let uploaded = utils::format_size(torrent.uploaded());
        let download_speed = utils::format_speed(torrent.download_speed());
        let upload_speed = utils::format_speed(torrent.upload_speed());
        let size = utils::format_size(torrent.size());

        if torrent.downloaded() == torrent.size() {
            /* Translators: First {} is the amount uploaded, second {} is the
             * uploading speed
             * Displayed under the torrent name in the main window when torrent
             * download is finished */
            i18n_f("{} uploaded · {}", &[&uploaded, &upload_speed])
        } else if torrent.status() == TrTorrentStatus::Stopped
            || torrent.status() == TrTorrentStatus::DownloadWait
        {
            /* Translators: First {} is the amount downloaded, second {} is the
             * total torrent size
             * Displayed under the torrent name in the main window when torrent
             * is stopped */
            i18n_f("{} of {}", &[&downloaded, &size])
        } else {
            /* Translators: First {} is the amount downloaded, second {} is the
             * total torrent size, third {} is the download speed
             * Displayed under the torrent name in the main window when torrent
             * is downloading */
            i18n_f("{} of {} · {}", &[&downloaded, &size, &download_speed])
        }
    }

    fn bind_property<T: IsA<gtk::Widget>>(
        &self,
        prop_name: &str,
        widget: T,
        widget_prop_name: &str,
    ) {
        self.torrent()
            .bind_property(prop_name, &widget, widget_prop_name)
            .flags(glib::BindingFlags::SYNC_CREATE)
            .build();
    }
}
