// Fragments - about_dialog.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use gtk::prelude::*;

use crate::config;
use crate::i18n::i18n;
use crate::ui::FrgApplicationWindow;

pub fn show_about_dialog() {
    let mut version = config::VERSION.to_string();

    let mut semver_major = version.split_at(1).0.parse::<i32>().unwrap();
    let semver_patch = version.split_at(4).1.parse::<i32>().unwrap();

    // We use x.9.x as a way to mark beta / development versions
    // eg. 1.9.3 -> 2.0 Beta 3
    let is_development = version.contains(".9.");
    if is_development {
        semver_major += 1;
        version = format!("{}.0", semver_major);
    }

    let version_text = if config::PROFILE == "development" {
        if is_development {
            format!(
                "{} Development Preview\n({} / Commit {})",
                version,
                config::VERSION,
                config::VCS_TAG
            )
        } else {
            format!(
                "{} Development Preview\n(Commit {})",
                config::VERSION,
                config::VCS_TAG
            )
        }
    } else if config::PROFILE == "beta" {
        if is_development {
            format!("{} Beta {} ({})", version, semver_patch, config::VERSION)
        } else {
            format!("{} Beta ({})", version, config::VERSION)
        }
    } else {
        config::VERSION.to_string()
    };

    let comment = i18n("A BitTorrent Client – Based on Transmission Technology");

    let dialog = gtk::AboutDialog::new();
    dialog.set_program_name(Some(config::NAME));
    dialog.set_logo_icon_name(Some(config::APP_ID));
    dialog.set_license_type(gtk::License::Gpl30);
    dialog.set_comments(Some(&comment));
    dialog.set_copyright(Some("© 2022 Felix Häcker"));
    dialog.set_website(Some("https://gitlab.gnome.org/World/Fragments"));
    dialog.set_version(Some(&version_text));
    dialog.set_modal(true);

    let window = FrgApplicationWindow::default();
    dialog.set_transient_for(Some(&window));

    dialog.set_authors(&[
        "Felix Häcker <haeckerfelix@gnome.org>",
        "Bilal Elmoussaoui <bilal.elmoussaoui@gnome.org>",
        "Maximiliano Sandoval",
    ]);
    dialog.set_artists(&["Tobias Bernard", "Jakub Steiner", "Sam Hewitt"]);

    dialog.show();
}
