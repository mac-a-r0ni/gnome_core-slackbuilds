// Fragments - connection_box.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use glib::{clone, subclass};
use gtk::subclass::prelude::*;
use gtk::CompositeTemplate;
use gtk::{glib, prelude::*};
use transmission_gobject::TrAuthentication;

use crate::app::FrgApplication;
use crate::backend::{secret_store, FrgConnectionManager};
use crate::config;
use crate::i18n::i18n;
use crate::i18n::i18n_f;
use crate::ui::FrgApplicationWindow;
use crate::utils;

enum View {
    Authentication,
    Loading,
    Empty, // Disconnected
    Ready,
    Torrents,
    Failure(String),
}

mod imp {
    use super::*;

    #[derive(Default, Debug, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/connection_box.ui")]
    pub struct FrgConnectionBox {
        #[template_child]
        pub stack: TemplateChild<gtk::Stack>,
        #[template_child]
        pub spinner: TemplateChild<gtk::Spinner>,
        #[template_child]
        pub welcome_status_page: TemplateChild<adw::StatusPage>,
        #[template_child]
        pub failure_status_page: TemplateChild<adw::StatusPage>,
        #[template_child]
        pub reconnect_button: TemplateChild<gtk::Button>,
        #[template_child]
        pub username_entry: TemplateChild<gtk::Entry>,
        #[template_child]
        pub password_entry: TemplateChild<gtk::PasswordEntry>,
        #[template_child]
        pub authenticate_button: TemplateChild<gtk::Button>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgConnectionBox {
        const NAME: &'static str = "FrgConnectionBox";
        type ParentType = gtk::Box;
        type Type = super::FrgConnectionBox;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgConnectionBox {
        fn constructed(&self, obj: &Self::Type) {
            obj.setup_widgets();
            obj.setup_signals();
            self.parent_constructed(obj);
        }
    }
    impl WidgetImpl for FrgConnectionBox {}
    impl BoxImpl for FrgConnectionBox {}
}

glib::wrapper! {
    pub struct FrgConnectionBox(
        ObjectSubclass<imp::FrgConnectionBox>)
        @extends gtk::Widget, gtk::Box;
}

impl FrgConnectionBox {
    fn setup_widgets(&self) {
        let imp = imp::FrgConnectionBox::from_instance(self);

        // Set welcome icon
        if config::PROFILE == "development" {
            let icon = Some("de.haeckerfelix.Fragments.Devel");
            imp.welcome_status_page.set_icon_name(icon);
        }

        // Initial view -> Loading
        self.set_view(View::Loading);
    }

    fn setup_signals(&self) {
        let imp = imp::FrgConnectionBox::from_instance(self);
        let client = FrgConnectionManager::default().client();

        // Show loading spinner if client is busy (eg. dis/connecting the session)
        client.connect_notify_local(
            Some("is-busy"),
            clone!(@weak self as this => move |client, _|{
                if client.is_busy(){
                    this.set_view(View::Loading);
                }else if !client.is_busy() && client.is_connected(){
                    this.update_torrents_view();
                }else{
                    this.set_view(View::Empty);
                }
            }),
        );

        client.connect_local(
            "connection-failure",
            false,
            clone!(@weak self as this => @default-return None, move |_|{
                let app = FrgApplication::default();
                let window = FrgApplicationWindow::default();

                let cm = FrgConnectionManager::default();
                let connection = cm.current_connection();

                window.inapp_notification(&i18n_f("Connection with {} was lost.", &[&connection.title()]));

                // Try to reconnect
                app.activate_action("set-connection", Some(&connection.uuid().to_variant()));
                None
            }),
        );

        // Update the view according to the torrent model
        client
            .torrents()
            .connect_items_changed(clone!(@weak self as this => move |_, _, _, _| {
                // We don't care about torrent model changes when we're not connected
                // (Avoids displaying empty state view when model gets cleared)
                if FrgConnectionManager::default().client().is_connected(){
                    this.update_torrents_view();
                }
            }));

        imp.reconnect_button
            .connect_clicked(clone!(@weak self as this => move |_|{
                FrgApplication::default().activate_action("reconnect", None);
            }));

        imp.authenticate_button.connect_clicked(clone!(@weak self as this => move |_|{
            let imp = imp::FrgConnectionBox::from_instance(&this);
            let cm = FrgConnectionManager::default();

            let auth = TrAuthentication::new(&imp.username_entry.text(), &imp.password_entry.text());
            cm.client().set_authentication(auth.clone());

            let res = secret_store::store(&cm.current_connection(), &auth);
            if let Err(err) = res{
                warn!("Credentials could not be saved: {}", err.to_string());
                utils::inapp_notification(i18n("Credentials could not be saved"));
            }

            FrgApplication::default().activate_action("reconnect", None);
        }));
    }

    fn update_torrents_view(&self) {
        let model = FrgConnectionManager::default().client().torrents();

        if model.n_items() == 0 {
            self.set_view(View::Ready);
        } else {
            self.set_view(View::Torrents);
        }
    }

    pub fn show_authentication(&self, failure: bool) {
        let imp = imp::FrgConnectionBox::from_instance(self);
        if failure {
            imp.username_entry.add_css_class("error");
            imp.password_entry.add_css_class("error");
        } else {
            imp.username_entry.remove_css_class("error");
            imp.password_entry.remove_css_class("error");
        }

        self.set_view(View::Authentication);
    }

    pub fn show_failure_message(&self, message: String) {
        self.set_view(View::Failure(message));
    }

    fn set_view(&self, view: View) {
        let imp = imp::FrgConnectionBox::from_instance(self);
        imp.spinner.set_spinning(false);

        let name = match view {
            View::Authentication => {
                // Unset previous entry text
                imp.username_entry.set_text("");
                imp.password_entry.set_text("");
                "authentication"
            }
            View::Loading => {
                imp.spinner.set_spinning(true);
                "loading"
            }
            View::Empty => "empty",
            View::Ready => "ready",
            View::Torrents => "torrents",
            View::Failure(err) => {
                imp.failure_status_page.set_description(Some(&err));
                "failure"
            }
        };

        imp.stack.set_visible_child_name(name);
    }
}
