// Fragments - torrent_page.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use adw::subclass::prelude::*;
use glib::clone;
use gtk::subclass::prelude::*;
use gtk::{glib, prelude::*};
use transmission_gobject::TrTorrentStatus;

use crate::backend::FrgConnectionManager;
use crate::model::{FrgTorrentFilter, FrgTorrentSorter, FrgTorrentSorting};
use crate::ui::FrgTorrentGroup;

mod imp {
    use super::*;
    use glib::subclass;
    use gtk::CompositeTemplate;

    #[derive(Default, Debug, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/torrent_page.ui")]
    pub struct FrgTorrentPage {
        #[template_child]
        pub downloading_group: TemplateChild<FrgTorrentGroup>,
        #[template_child]
        pub queued_group: TemplateChild<FrgTorrentGroup>,
        #[template_child]
        pub seeding_group: TemplateChild<FrgTorrentGroup>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgTorrentPage {
        const NAME: &'static str = "FrgTorrentPage";
        type ParentType = adw::PreferencesPage;
        type Type = super::FrgTorrentPage;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgTorrentPage {
        fn constructed(&self, obj: &Self::Type) {
            obj.setup_widgets();
            obj.setup_signals();
            self.parent_constructed(obj);
        }
    }

    impl WidgetImpl for FrgTorrentPage {}
    impl PreferencesPageImpl for FrgTorrentPage {}
}

glib::wrapper! {
    pub struct FrgTorrentPage(
        ObjectSubclass<imp::FrgTorrentPage>)
        @extends gtk::Widget, adw::PreferencesPage;

}

impl FrgTorrentPage {
    fn setup_widgets(&self) {
        let imp = imp::FrgTorrentPage::from_instance(&self);

        /* Downloading group */
        imp.downloading_group
            .add_model(self.model(TrTorrentStatus::Download, FrgTorrentSorting::Name));

        /* Queued group */
        imp.queued_group
            .add_model(self.model(TrTorrentStatus::DownloadWait, FrgTorrentSorting::Queue));
        imp.queued_group
            .add_model(self.model(TrTorrentStatus::Stopped, FrgTorrentSorting::Name));
        imp.queued_group
            .add_model(self.model(TrTorrentStatus::Check, FrgTorrentSorting::Name));
        imp.queued_group
            .add_model(self.model(TrTorrentStatus::CheckWait, FrgTorrentSorting::Name));

        /* Seeding group */
        imp.seeding_group
            .add_model(self.model(TrTorrentStatus::Seed, FrgTorrentSorting::Name));
        imp.seeding_group
            .add_model(self.model(TrTorrentStatus::SeedWait, FrgTorrentSorting::Name));
    }

    fn setup_signals(&self) {
        let _imp = imp::FrgTorrentPage::from_instance(&self);
    }

    fn model(&self, status: TrTorrentStatus, sorting: FrgTorrentSorting) -> gtk::SortListModel {
        let model = FrgConnectionManager::default().client().torrents();

        let filter = FrgTorrentFilter::new();
        filter.set_status(status);
        let filter_model = gtk::FilterListModel::new(Some(&model), Some(&filter));

        let sorter = FrgTorrentSorter::new();
        sorter.set_sorting(sorting);
        let sort_model = gtk::SortListModel::new(Some(&filter_model), Some(&sorter));

        model.connect_local(
            "status-changed",
            false,
            clone!(@weak filter, @weak sorter => @default-return None, move |_| {
                filter.changed(gtk::FilterChange::Different);
                sorter.changed(gtk::SorterChange::Different);
                None
            }),
        );

        sort_model
    }
}
