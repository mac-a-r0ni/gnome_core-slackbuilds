// Fragments - stats_dialog.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use adw::prelude::*;
use adw::subclass::prelude::*;
use glib::{clone, BindingFlags};
use gtk::glib;
use gtk::subclass::prelude::*;
use gtk::CompositeTemplate;

use std::convert::TryInto;

use crate::backend::FrgConnectionManager;
use crate::i18n::{i18n_f, ni18n_f};
use crate::ui::FrgApplicationWindow;
use crate::utils;

mod imp {
    use super::*;
    use glib::subclass;

    #[derive(Debug, Default, CompositeTemplate)]
    #[template(resource = "/de/haeckerfelix/Fragments/gtk/stats_dialog.ui")]
    pub struct FrgStatsDialog {
        #[template_child]
        pub remote_notice_group: TemplateChild<adw::PreferencesGroup>,
        #[template_child]
        pub remote_notice_row: TemplateChild<adw::ActionRow>,

        #[template_child]
        pub version_label: TemplateChild<gtk::Label>,

        #[template_child]
        pub downloaded_torrents_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub download_speed_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub upload_speed_label: TemplateChild<gtk::Label>,

        #[template_child]
        pub torrents_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub active_torrents_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub paused_torrents_label: TemplateChild<gtk::Label>,

        #[template_child]
        pub current_time_active_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub current_downloaded_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub current_uploaded_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub current_files_added_label: TemplateChild<gtk::Label>,

        #[template_child]
        pub cumulative_time_active_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub cumulative_downloaded_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub cumulative_uploaded_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub cumulative_files_added_label: TemplateChild<gtk::Label>,
        #[template_child]
        pub cumulative_sessions_label: TemplateChild<gtk::Label>,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgStatsDialog {
        const NAME: &'static str = "FrgStatsDialog";
        type ParentType = gtk::Dialog;
        type Type = super::FrgStatsDialog;

        fn class_init(klass: &mut Self::Class) {
            Self::bind_template(klass);
        }

        fn instance_init(obj: &subclass::InitializingObject<Self>) {
            obj.init_template();
        }
    }

    impl ObjectImpl for FrgStatsDialog {}

    impl WidgetImpl for FrgStatsDialog {}

    impl WindowImpl for FrgStatsDialog {}

    impl DialogImpl for FrgStatsDialog {}
}

glib::wrapper! {
    pub struct FrgStatsDialog(ObjectSubclass<imp::FrgStatsDialog>)
        @extends gtk::Widget, gtk::Window, adw::Window;
}

impl FrgStatsDialog {
    pub fn new() -> Self {
        let dialog: Self = glib::Object::new(&[("use-header-bar", &1)]).unwrap();

        let window = FrgApplicationWindow::default();
        dialog.set_transient_for(Some(&window));

        dialog.bind_properties();
        dialog.setup_signals();
        dialog.update_format_strings();
        dialog.update_remote_notice();
        dialog
    }

    fn bind_properties(&self) {
        let imp = imp::FrgStatsDialog::from_instance(self);
        let client = FrgConnectionManager::default().client();
        let session = client.session();
        let stats = client.session_stats();
        let current = stats.current_stats();
        let cumulative = stats.cumulative_stats();

        session
            .bind_property("version", &imp.version_label.get(), "label")
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        stats
            .bind_property(
                "active-torrent-count",
                &imp.active_torrents_label.get(),
                "label",
            )
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        stats
            .bind_property(
                "paused-torrent-count",
                &imp.paused_torrents_label.get(),
                "label",
            )
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        stats
            .bind_property(
                "downloaded-torrent-count",
                &imp.downloaded_torrents_label.get(),
                "label",
            )
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        stats
            .bind_property(
                "downloaded-torrent-count",
                &imp.downloaded_torrents_label.get(),
                "label",
            )
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        current
            .bind_property("files-added", &imp.current_files_added_label.get(), "label")
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        cumulative
            .bind_property(
                "files-added",
                &imp.cumulative_files_added_label.get(),
                "label",
            )
            .flags(BindingFlags::SYNC_CREATE)
            .build();

        stats.connect_notify_local(
            Some("download-speed"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        stats.connect_notify_local(
            Some("upload-speed"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        current.connect_notify_local(
            Some("seconds-active"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        current.connect_notify_local(
            Some("downloaded-bytes"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        current.connect_notify_local(
            Some("uploaded-bytes"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        cumulative.connect_notify_local(
            Some("seconds-active"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        cumulative.connect_notify_local(
            Some("downloaded-bytes"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        cumulative.connect_notify_local(
            Some("uploaded-bytes"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );

        cumulative.connect_notify_local(
            Some("sesison-count"),
            clone!(@weak self as this => move |_, _|{
                this.update_format_strings();
            }),
        );
    }

    fn setup_signals(&self) {
        FrgConnectionManager::default().connect_notify_local(
            Some("current-connection"),
            clone!(@weak self as this => move |_, _|{
                this.update_remote_notice();
            }),
        );
    }

    fn update_format_strings(&self) {
        let imp = imp::FrgStatsDialog::from_instance(self);
        let stats = FrgConnectionManager::default().client().session_stats();
        let current = stats.current_stats();
        let cumulative = stats.cumulative_stats();

        let speed = utils::format_speed(stats.download_speed().into());
        imp.download_speed_label.set_label(&speed);

        let speed = utils::format_speed(stats.upload_speed().into());
        imp.upload_speed_label.set_label(&speed);

        // Current
        let time = utils::format_time(current.seconds_active().try_into().unwrap(), false);
        imp.current_time_active_label.set_label(&time);

        let size = utils::format_size(current.downloaded_bytes());
        imp.current_downloaded_label.set_label(&size);

        let size = utils::format_size(current.uploaded_bytes());
        imp.current_uploaded_label.set_label(&size);

        // Cumulative
        let time = utils::format_time(cumulative.seconds_active().try_into().unwrap(), false);
        imp.cumulative_time_active_label.set_label(&time);

        let size = utils::format_size(cumulative.downloaded_bytes());
        imp.cumulative_downloaded_label.set_label(&size);

        let size = utils::format_size(cumulative.uploaded_bytes());
        imp.cumulative_uploaded_label.set_label(&size);

        let started = cumulative.session_count();
        let text = ni18n_f(
            "{} time",
            "{} times",
            started.try_into().unwrap_or(2),
            &[&started.to_string()],
        );
        imp.cumulative_sessions_label.set_label(&text);
    }

    fn update_remote_notice(&self) {
        let imp = imp::FrgStatsDialog::from_instance(self);
        let cm = FrgConnectionManager::default();

        let is_fragments = cm.current_connection().is_fragments();
        let title = cm.current_connection().title();

        imp.remote_notice_group.set_visible(!is_fragments);
        imp.remote_notice_row
            .set_title(&i18n_f("You are connected with “{}”", &[&title]));
    }
}
