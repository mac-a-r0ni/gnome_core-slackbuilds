// Fragments - app.rs
// Copyright (C) 2022  Felix Häcker <haeckerfelix@gnome.org>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

use async_std::fs;
use futures_util::FutureExt;
use glib::clone;
use glib::SignalHandlerId;
use glib::WeakRef;
use glib::{ParamFlags, ParamSpec, ParamSpecObject};
use gtk::subclass::prelude::*;
use gtk::{gdk, gio, glib, prelude::*};
use gtk::{FileChooserAction, FileChooserNative, FileFilter, ResponseType};
use once_cell::sync::{Lazy, OnceCell};
use transmission_gobject::TrClient;

use std::cell::RefCell;
use std::rc::Rc;

use crate::backend::{secret_store, FrgConnection, FrgConnectionManager};
use crate::config;
use crate::i18n::{i18n, i18n_f};
use crate::settings::{settings_manager, Key};
use crate::ui::{
    about_dialog, FrgAddConnectionDialog, FrgApplicationWindow, FrgPreferencesWindow,
    FrgStatsDialog,
};
use crate::utils;

mod imp {
    use super::*;

    pub struct FrgApplication {
        pub connection_manager: FrgConnectionManager,
        pub connected_handler: OnceCell<SignalHandlerId>,
        pub window: OnceCell<WeakRef<FrgApplicationWindow>>,
        pub settings: gio::Settings,
    }

    #[glib::object_subclass]
    impl ObjectSubclass for FrgApplication {
        const NAME: &'static str = "FrgApplication";
        type Type = super::FrgApplication;
        type ParentType = gtk::Application;

        fn new() -> Self {
            let app_id = config::APP_ID.trim_end_matches(".Devel");

            let connection_manager = FrgConnectionManager::new();
            let connected_handler = OnceCell::new();
            let window = OnceCell::new();

            Self {
                connection_manager,
                connected_handler,
                window,
                settings: gio::Settings::new(app_id),
            }
        }
    }

    impl ObjectImpl for FrgApplication {
        fn properties() -> &'static [ParamSpec] {
            static PROPERTIES: Lazy<Vec<ParamSpec>> = Lazy::new(|| {
                vec![ParamSpecObject::new(
                    "connection-manager",
                    "Connection manager",
                    "Connection manager",
                    FrgConnectionManager::static_type(),
                    ParamFlags::READABLE,
                )]
            });
            PROPERTIES.as_ref()
        }

        fn property(&self, _obj: &Self::Type, _id: usize, pspec: &ParamSpec) -> glib::Value {
            match pspec.name() {
                "connection-manager" => self.connection_manager.to_value(),
                _ => unimplemented!(),
            }
        }
    }

    impl GtkApplicationImpl for FrgApplication {}

    impl ApplicationImpl for FrgApplication {
        fn activate(&self, app: &Self::Type) {
            debug!("Activate GIO Application...");

            // If the window already exists,
            // present it instead creating a new one again.
            if let Some(weak_win) = self.window.get() {
                let window = weak_win.upgrade().unwrap();
                window.present();
                info!("Application window presented.");
                return;
            }

            debug!("Setup Fragments base components...");
            app.setup_app();

            debug!("Create new application window...");
            let window = app.create_window();
            window.present();
            self.window.set(window.downgrade()).unwrap();

            // Setup GActions
            app.setup_gactions();
            app.update_session_gactions();
        }

        fn open(&self, application: &Self::Type, files: &[gio::File], _hint: &str) {
            application.activate();
            debug!("Application {} handling files.", config::APP_ID);

            let client = self.connection_manager.client();
            let files_store = gio::ListStore::new(gio::File::static_type());
            for file in files {
                files_store.append(file);
            }

            if client.is_connected() {
                application.add_torrents_from_files(&files_store.upcast());
            } else {
                // Wait till we're connected with something to add the files
                let signal_id: Rc<RefCell<Option<glib::SignalHandlerId>>> = Rc::default();
                *signal_id.borrow_mut() = Some(client.connect_notify_local(
                    Some("is-connected"),
                    clone!(@weak application, @strong signal_id, @strong files_store => move |client, _| {
                        if client.is_connected() {
                            application.add_torrents_from_files(&files_store.clone().upcast());

                            // Disconnect from the signal, we only need it one time
                            let signal_id = signal_id.borrow_mut().take().unwrap();
                            glib::ObjectExt::disconnect(client, signal_id);
                        }
                    }),
                ));
            }
        }
    }
}

glib::wrapper! {
    pub struct FrgApplication(
        ObjectSubclass<imp::FrgApplication>)
        @extends gio::Application, gtk::Application, gio::ActionMap, gio::ActionGroup;
}

// FrgApplication implementation itself
impl FrgApplication {
    pub fn run() {
        info!(
            "{} ({}) ({})",
            config::NAME,
            config::APP_ID,
            config::VCS_TAG
        );
        info!("Version: {} ({})", config::VERSION, config::PROFILE);

        // Create new GObject and downcast it into FrgApplication
        let app = glib::Object::new::<FrgApplication>(&[
            ("application-id", &Some(config::APP_ID)),
            ("flags", &gio::ApplicationFlags::HANDLES_OPEN),
            ("resource-base-path", &Some("/de/haeckerfelix/Fragments")),
        ])
        .unwrap();

        app.set_default();

        // Start running gtk::Application
        ApplicationExtManual::run(&app);
    }

    fn create_window(&self) -> FrgApplicationWindow {
        let window = FrgApplicationWindow::new(&self);

        // Load custom styling
        let p = gtk::CssProvider::new();
        gtk::CssProvider::load_from_resource(&p, "/de/haeckerfelix/Fragments/gtk/style.css");
        gtk::StyleContext::add_provider_for_display(&gdk::Display::default().unwrap(), &p, 500);

        window
    }

    fn setup_app(&self) {
        let imp = imp::FrgApplication::from_instance(self);

        // Start transmission daemon, and connect session to it (or to last used connection).
        let fut = clone!(@weak self as this => async move {
            let cm = FrgConnectionManager::default();
            cm.start_daemon().await.unwrap();

            let local_connection = FrgConnection::default();
            cm.connections().insert(0, &local_connection);

            // Restore last used connection
            let uuid = settings_manager::get_string(Key::ClientLastConnection);
            this.set_connection(uuid).await;
        });
        spawn!(fut);

        imp.settings.connect_changed(
            Some("dark-mode"),
            clone!(@weak self as app => move |_, _| {
                    app.update_color_scheme();
                }
            ),
        );

        self.update_color_scheme();
    }

    fn setup_gactions(&self) {
        let string_ty = Some(glib::VariantTy::new("s").unwrap());

        // app.add-torrent
        let action = gio::SimpleAction::new("add-torrent", None);
        action.connect_activate(clone!(@weak self as app => move |_, _| {
            app.open_torrent_filechooser();
        }));
        utils::bind_connected_property(&action);
        self.add_action(&action);
        self.set_accels_for_action("app.add-torrent", &["<primary>o"]);

        // app.add-magnet
        let action = gio::SimpleAction::new("add-magnet", string_ty);
        action.connect_activate(clone!(@weak self as this => move |_, target| {
            if let Some(magnet) = target.map(|x| x.get::<String>()).flatten() {
                this.add_torrent_by_magnet(magnet);
            }
        }));
        utils::bind_connected_property(&action);
        self.add_action(&action);

        // app.pause-torrents
        let action = gio::SimpleAction::new("pause-torrents", None);
        action.connect_activate(clone!(@weak self as app => move |_, _| {
            let fut = async move {
                let client = FrgConnectionManager::default().client();
                if let Err(err) = client.stop_torrents().await {
                    debug!("Could not pause torrents: {:?}", err);
                };
            };
            spawn!(fut);

        }));
        self.add_action(&action);

        // app.remove-torrents
        let action = gio::SimpleAction::new("remove-torrents", None);
        action.connect_activate(clone!(@weak self as app => move |_, _| {
            app.show_remove_torrents_dialog();
        }));
        self.add_action(&action);

        // app.show-stats
        let action = gio::SimpleAction::new("show-stats", None);
        action.connect_activate(move |_, _| {
            FrgStatsDialog::new().show();
        });
        utils::bind_connected_property(&action);
        self.add_action(&action);

        // app.set-connection
        let action = gio::SimpleAction::new("set-connection", string_ty);
        action.connect_activate(clone!(@weak self as this => move |_, target| {
            if let Some(connection_uuid) = target.map(|x| x.get::<String>()).flatten() {
                let fut = async move {
                    this.set_connection(connection_uuid).await;
                };
                spawn!(fut);
            }
        }));
        self.add_action(&action);

        // app.reconnect
        let action = gio::SimpleAction::new("reconnect", None);
        action.connect_activate(clone!(@weak self as this => move |_, _| {
            let cm = FrgConnectionManager::default();
            this.activate_action("set-connection", Some(&cm.current_connection().uuid().to_variant()));
        }));
        self.add_action(&action);

        // app.add-remote-connection
        let action = gio::SimpleAction::new("add-remote-connection", None);
        action.connect_activate(move |_, _| {
            FrgAddConnectionDialog::new().show();
        });
        self.add_action(&action);

        // app.show-preferences
        let action = gio::SimpleAction::new("show-preferences", None);
        action.connect_activate(move |_, _| {
            FrgPreferencesWindow::new().show();
        });
        self.set_accels_for_action("app.show-preferences", &["<primary>comma"]);
        self.add_action(&action);

        // app.about
        let action = gio::SimpleAction::new("about", None);
        action.connect_activate(move |_, _| {
            about_dialog::show_about_dialog();
        });
        self.add_action(&action);

        // app.quit
        let action = gio::SimpleAction::new("quit", None);
        action.connect_activate(move |_, _| {
            let window = FrgApplicationWindow::default();
            window.close();
        });
        self.set_accels_for_action("app.quit", &["<primary>q"]);
        self.add_action(&action);

        // Update state of `pause-torrents` and `remove-torrents` action
        let stats = FrgConnectionManager::default().client().session_stats();
        stats.connect_notify_local(
            Some("downloaded-torrent-count"),
            clone!(@weak self as this => move |_, _|{
                this.update_session_gactions();
            }),
        );
        stats.connect_notify_local(
            Some("paused-torrent-count"),
            clone!(@weak self as this => move |_, _|{
                this.update_session_gactions();
            }),
        );
        stats.connect_notify_local(
            Some("torrent-count"),
            clone!(@weak self as this => move |_, _|{
                this.update_session_gactions();
            }),
        );
        let client = FrgConnectionManager::default().client();
        client.connect_notify_local(
            Some("is-connected"),
            clone!(@weak self as this => move |_, _|{
                this.update_session_gactions();
            }),
        );
    }

    // Disable the `pause-torrents` or `remove-torrents` if there's no connection
    // or there are no torrents available to apply the action
    // eg. no 100% downloaded torrents avilable -> disable `remove-torrents` action
    fn update_session_gactions(&self) {
        let client = FrgConnectionManager::default().client();
        let stats = client.session_stats();

        let pause_torrents_action: gio::SimpleAction = self
            .lookup_action("pause-torrents")
            .unwrap()
            .downcast()
            .unwrap();

        let remove_torrents_action: gio::SimpleAction = self
            .lookup_action("remove-torrents")
            .unwrap()
            .downcast()
            .unwrap();

        if !client.is_connected() {
            pause_torrents_action.set_enabled(false);
            remove_torrents_action.set_enabled(false);
        } else {
            let pause_action = stats.paused_torrent_count() != stats.torrent_count();
            pause_torrents_action.set_enabled(pause_action);

            let remove_action = stats.downloaded_torrent_count() != 0;
            remove_torrents_action.set_enabled(remove_action);
        }
    }

    pub fn connection_manager(&self) -> FrgConnectionManager {
        self.property("connection_manager")
    }

    fn add_torrents_from_files(&self, files: &gio::ListModel) {
        for pos in 0..files.n_items() {
            let file = files.item(pos).unwrap().downcast::<gio::File>().unwrap();

            if file.has_uri_scheme("magnet") {
                let mut magnet = file.uri().to_string();
                magnet = magnet.replace("magnet:///", "magnet:");
                self.add_torrent_by_magnet(magnet);
            } else {
                self.add_torrent_by_file(&file);
            }
        }
    }

    fn add_torrent_by_file(&self, file: &gio::File) {
        debug!("Add torrent by file: {:?}", file.path());
        let file = file.path().unwrap();

        let fut = async move {
            match fs::read(file).await {
                Ok(content) => {
                    let encoded = base64::encode(content);

                    let cm = FrgConnectionManager::default();
                    let res = cm.add_torrent_by_metainfo(encoded).await;
                    if let Err(err) = res {
                        debug!("Could not add file torrent: {:?}", err);
                        utils::inapp_notification("Unable to add file torrent");
                    }
                }
                Err(err) => {
                    debug!("Unable to read file content: {:?}", err);
                    utils::inapp_notification("Unable to read file content");
                }
            }
        };

        spawn!(fut);
    }

    fn add_torrent_by_magnet(&self, magnet: String) {
        debug!("Add torrent by magnet: {}", magnet);
        let fut = async move {
            let cm = FrgConnectionManager::default();
            cm.add_torrent_by_filename(magnet.to_string())
                .map(move |result| match result {
                    Ok(_) => (),
                    Err(err) => {
                        debug!("Could not add magnet torrent: {:?}", err);
                        utils::inapp_notification("Unable to add magnet torrent");
                    }
                })
                .await;
        };

        spawn!(fut);
    }

    async fn set_connection(&self, connection_uuid: String) {
        let cm = FrgConnectionManager::default();
        let window = FrgApplicationWindow::default();

        if let Some(connection) = cm.connection_by_uuid(&connection_uuid) {
            let res = cm.connect(&connection).await;

            if let Err(err) = &res {
                if utils::is_unauthorized(&res) {
                    if let Ok(Some(auth)) = secret_store::get(&connection) {
                        // Test if the saved credentials are valid
                        let res =
                            TrClient::test_connectivity(connection.address(), Some(auth.clone()))
                                .await;
                        if utils::is_unauthorized(&res) {
                            // Nope -> Show authentication page again
                            window.show_authentication(true);
                        } else {
                            cm.client().set_authentication(auth);
                            FrgApplication::default().activate_action("reconnect", None);
                        }
                    } else {
                        window.show_authentication(false);
                    }
                } else {
                    let msg = i18n_f(
                        "Failed to establish a connection with the Transmission service (“{}”).",
                        &[&err.to_string()],
                    );
                    window.show_connection_failure_message(&msg);
                }
            }
        } else {
            let msg = i18n_f("No connection found with UUID \"{}\"", &[&connection_uuid]);
            window.inapp_notification(&msg);

            // Fallback to local Fragments connection
            let default_uuid = FrgConnection::default().uuid();
            if connection_uuid != default_uuid {
                self.activate_action("set-connection", Some(&default_uuid.to_variant()));
            }
        }
    }

    fn open_torrent_filechooser(&self) {
        let window = FrgApplicationWindow::default();
        let dialog = FileChooserNative::new(
            Some(&i18n("Open Torrents")),
            Some(&window),
            FileChooserAction::Open,
            Some(&i18n("_Open")),
            None,
        );

        dialog.set_modal(true);
        dialog.set_select_multiple(true);

        // Set a filter to only show torrent files
        let filter = FileFilter::new();
        FileFilter::set_name(&filter, Some(&i18n("Torrent files")));
        filter.add_mime_type("application/x-bittorrent");
        dialog.add_filter(&filter);

        // Set a filter to show all files
        let all_files_filter = FileFilter::new();
        FileFilter::set_name(&all_files_filter, Some(&i18n("All files")));
        all_files_filter.add_pattern("*");
        dialog.add_filter(&all_files_filter);

        dialog.connect_response(
            clone!(@strong dialog, @weak self as this => move |_, resp| {
                if resp == ResponseType::Accept {
                    this.add_torrents_from_files(&dialog.files());
                }
            }),
        );

        dialog.show();
    }

    fn update_color_scheme(&self) {
        let manager = adw::StyleManager::default();

        if !manager.system_supports_color_schemes() {
            let color_scheme = if settings_manager::get_boolean(Key::DarkMode) {
                adw::ColorScheme::PreferDark
            } else {
                adw::ColorScheme::PreferLight
            };
            manager.set_color_scheme(color_scheme);
        }
    }

    fn show_remove_torrents_dialog(&self) {
        let window = self.active_window().unwrap();
        let dialog = gtk::MessageDialog::new(
            Some(&window),
            gtk::DialogFlags::MODAL,
            gtk::MessageType::Question,
            gtk::ButtonsType::None,
            "",
        );
        // NOTE: Title of the modal when the user removes all downloaded torrents
        dialog.set_text(Some(&i18n("Remove all Downloaded Torrents?")));
        // NOTE: Text displayed in the modal when the user removes all downloaded torrents
        dialog.set_secondary_text(Some(&i18n(
            "This will only remove torrents from Fragments, but will keep the downloaded content.",
        )));

        dialog.add_button(&i18n("_Cancel"), gtk::ResponseType::Cancel);
        dialog.add_button(&i18n("_Remove"), gtk::ResponseType::Ok);

        dialog.connect_response(move |dialog, response| {
            dialog.destroy();
            if response == gtk::ResponseType::Ok {
                let fut = async move {
                    let client = FrgConnectionManager::default().client();
                    if let Err(err) = client.remove_torrents(true, false).await {
                        debug!("Could not remove torrents: {:?}", err);
                    };
                };
                spawn!(fut);
            }
        });

        dialog.show();
    }
}

impl Default for FrgApplication {
    fn default() -> Self {
        gio::Application::default()
            .expect("Could not get default GApplication")
            .downcast()
            .unwrap()
    }
}
