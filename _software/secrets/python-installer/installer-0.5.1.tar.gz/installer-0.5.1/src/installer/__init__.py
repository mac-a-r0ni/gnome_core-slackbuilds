"""A library for installing Python wheels."""

__version__ = "0.5.1"
__all__ = ["install"]

from installer._core import install  # noqa
