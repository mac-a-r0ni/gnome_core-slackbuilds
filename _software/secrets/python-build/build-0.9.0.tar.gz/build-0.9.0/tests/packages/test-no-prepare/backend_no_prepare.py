# SPDX-License-Identifier: MIT

from setuptools.build_meta import build_sdist, build_wheel  # noqa: F401
