Detailed description of the feature. Put as much information as you can.

Proposed Mockups:

(Add mockups of the proposed feature)

## Design Tasks

* [ ]  design tasks

## Development Tasks

* [ ]  development tasks

## QA Tasks

* [ ]  qa (quality assurance) tasks
