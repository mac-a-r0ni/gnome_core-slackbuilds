Detailed description of the issue. Put as much information as you can, potentially
with images showing the issue.

Steps to reproduce:

1. Open Endeavour
2. Create a task
3. ...

## Design Tasks

* [ ]  design tasks

## Development Tasks

* [ ]  development tasks

## QA Tasks

* [ ]  qa (quality assurance) tasks
