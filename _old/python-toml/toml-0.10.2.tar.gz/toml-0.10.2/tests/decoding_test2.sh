#!/bin/sh

export PYTHONPATH=`pwd`
python2 tests/decoding_test.py
