scp -r *.htm *.css hughsient@people.freedesktop.org:~/public_html/appstream-glib
scp ../api/html/* hughsient@people.freedesktop.org:~/public_html/appstream-glib/docs
