/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*-
 *
 * Copyright (C) 2014 Richard Hughes <richard@hughsie.com>
 *
 * SPDX-License-Identifier: LGPL-2.1+
 */

#pragma once

#define __APPSTREAM_BUILDER_H_INSIDE__

#include <asb-context.h>

#undef __APPSTREAM_BUILDER_H_INSIDE__
