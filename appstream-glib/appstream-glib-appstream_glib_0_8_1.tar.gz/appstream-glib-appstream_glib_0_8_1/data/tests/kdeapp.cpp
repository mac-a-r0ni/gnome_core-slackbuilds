// lupdate-qt4 kdeapp.pro && lrelease-qt4 kdeapp.pro

//TRANSLATIONS: comment
label->setText(QObject::tr("Hello World"))
