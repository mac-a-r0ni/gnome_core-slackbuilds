## AppStream Documentation XSL Style

This style is based on the DAPS documentation template made by openSUSE.
it is significantly reduced and lacks a few features present in the original,
also the branding is different.
Check out the original at https://github.com/openSUSE/suse-xsl

Original license of the style is GPL-2.0 or GPL-3.0:
```
 Copyright (c) 2003-2016, SUSE LLC

 All Rights Reserved.

 This program is free software; you can redistribute it and/or
 modify it under the terms of version 2 or version 3 at your choice
 of the GNU General Public License as published by the Free Software
 Foundation.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, contact SUSE LLC

 To contact SUSE LLC about this file by physical or
 electronic mail, you may find current contact information at www.suse.com
```
